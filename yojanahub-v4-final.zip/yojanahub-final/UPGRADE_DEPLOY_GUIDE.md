# 🚀 YojanaHub v4.0 — Upgrade & Deploy Guide
**Revenue Target: ₹1L–₹10L/month**

---

## 📦 What's New in v4.0

### ✅ Systems Added
| System | File | Status |
|---|---|---|
| 120+ Blog Topics Pool | `functions/blogGenerator.js` | ✅ New |
| Internal Linking Engine | `functions/internalLinking.js` | ✅ New |
| Security Layer (WAF, Rate Limiting, DDoS) | `functions/security.js` | ✅ New |
| Blog Seed Engine (50–150 blogs instantly) | `functions/seedBlogs.js` | ✅ New |
| Client Analytics Tracker | `public/js/analytics.js` | ✅ New |
| Trending Now Ticker on Blog Page | `public/blog/index.html` | ✅ New |
| Dual CRON (5AM + 2PM blogs) | `functions/index.js` | ✅ New |
| Hardened Firestore Rules | `firestore.rules` | ✅ Upgraded |
| Full Security Headers (CSP, HSTS) | `firebase.json` | ✅ Upgraded |
| 16 New Category Filters | `public/blog/index.html` | ✅ New |

---

## 🚀 STEP 1 — Deploy Functions

```bash
cd functions
npm install
cd ..

# Set Anthropic API key (for AI blog generation)
firebase functions:config:set anthropic.key="sk-ant-YOUR_KEY_HERE"

# Set seed key (used to trigger one-time blog seeding)
firebase functions:config:set seed.key="yourSecretSeedKey2026"

# Deploy everything
firebase deploy
```

---

## 🌱 STEP 2 — Seed 100+ Blogs Instantly

After deploy, call this URL once to populate 100 blogs immediately:

```
GET https://us-central1-yojanahub.cloudfunctions.net/seedBlogs?key=yourSecretSeedKey2026&count=100
```

**What this does:**
- Creates 100 placeholder blogs in Firestore instantly
- Spreads publishDates over past 60 days (natural SEO appearance)
- Each blog gets internal links to 3 related articles
- Generates blog count: 100 → visible in /blog/ page immediately
- CRON will then generate AI-upgraded versions daily (3–5/day)

To seed with AI content (higher quality, takes longer):
```
GET .../seedBlogs?key=yourSecretSeedKey2026&count=50&aiKey=sk-ant-YOUR_KEY
```

---

## 🔑 STEP 3 — Configure AdSense

Replace in ALL files:
- `ca-pub-YOUR_PUB_ID` → Your AdSense Publisher ID
- `YOUR_LEADERBOARD_SLOT` → Your leaderboard ad slot ID
- `YOUR_MID_CONTENT_SLOT` → Your in-content ad slot ID
- `YOUR_BOTTOM_SLOT` → Your bottom ad slot ID

Files to update:
- `public/blog/index.html`
- `functions/blogGenerator.js` (line: `ca-pub-YOUR_PUB_ID`)

---

## 🔐 STEP 4 — Security Configuration

The security system is **automatically active** after deploy. It provides:

- **Rate Limiting**: 30 req/min for search, 60/min for trending, 20/min for other APIs
- **IP Blocklist**: Automatic blocking after 10 rate-limit violations
- **Input Sanitization**: All user inputs sanitized, XSS/injection blocked
- **Security Headers**: CSP, HSTS, X-Frame-Options, XSS-Protection on all pages
- **Firestore Rules**: Injection-pattern detection, field validation, no PII exposure

Check security status (replace KEY with a secure random string):
```
firebase functions:config:set security.admin_key="your-admin-key-here"
GET .../securityStatus?key=your-admin-key-here
```

---

## ⚙️ STEP 5 — Automated Blog CRON Schedule

| Time (IST) | Function | Action |
|---|---|---|
| 5:00 AM | `generateBlogs` | Generates 3 AI blogs |
| 2:00 PM | `generateBlogsPM` | Generates 2 more blogs |
| 3:00 AM | `scheduledSitemap` | Rebuilds sitemap.xml |
| Every 12h | `updateTrending` | Updates trending data |
| Every 6h | `scrapeSchemes` | Scrapes new schemes |
| Every 6h+30m | `scrapeJobs` | Scrapes new jobs |
| Weekly Mon 4AM | `backfillLinks` | Adds internal links to old blogs |
| Weekly Sun 2AM | `weeklyCleanup` | Deletes old analytics, marks expired jobs |

**Result:** 5 new blogs/day × 30 days = 150 new blogs/month automatically

---

## 📈 Blog Scaling Timeline

| Day | Blogs | Traffic Estimate |
|---|---|---|
| Day 1 (after seed) | 100 | 500–1,000 visits/day |
| Day 30 | 250 | 3,000–8,000 visits/day |
| Day 90 | 450 | 10,000–30,000 visits/day |
| Day 180 | 750+ | 40,000–100,000 visits/day |

---

## 💰 Revenue Projection (AdSense)

| Traffic | RPM | Daily Revenue | Monthly Revenue |
|---|---|---|---|
| 3,000 visits/day | ₹120 | ₹360 | ₹10,800 |
| 10,000 visits/day | ₹130 | ₹1,300 | ₹39,000 |
| 30,000 visits/day | ₹150 | ₹4,500 | ₹1,35,000 |
| 1,00,000 visits/day | ₹160 | ₹16,000 | ₹4,80,000 |

**High-CPC Categories in the Blog Pool:**
- Loan + CIBIL keywords: ₹80–₹200 CPC
- Insurance (PMJJBY, Ayushman): ₹60–₹150 CPC
- Jobs (SSC, Railway, UPSC): ₹40–₹100 CPC
- Farmer schemes (PM Kisan): ₹50–₹120 CPC

---

## 🔗 New API Endpoints

| Endpoint | Purpose |
|---|---|
| `GET /api/trending` | Returns trending blogs/schemes/jobs + breaking news |
| `GET /api/internal-links?slug=SLUG` | Returns related content + HTML for a blog |
| `GET /api/search?q=QUERY` | Searches schemes, jobs, blogs |
| `GET /api/seedBlogs?key=KEY&count=N` | Seeds N blogs (one-time) |
| `GET /sitemap.xml` | Dynamic sitemap with all URLs |

---

## 🛡️ Security Features Summary

1. **Rate Limiter** — In-memory per-IP, per-endpoint limits
2. **IP Blocklist** — Persistent in Firestore, auto-cached
3. **Injection Detection** — NoSQL/SQL/XSS/path traversal patterns blocked
4. **Input Sanitization** — All user strings cleaned before DB writes
5. **Security Headers** — CSP, HSTS, XSS-Protection, Referrer-Policy
6. **CORS Validation** — Only yojanahub.in domain allowed
7. **Firestore Rules** — Server-side validation, injection patterns blocked
8. **Auto IP Blocking** — 10+ rate violations = permanent block
9. **Security Audit Log** — All attacks logged to `security_logs` collection

---

## 📁 File Structure

```
yojanahub-v4/
├── firebase.json              ← Full security headers + new rewrites
├── firestore.rules            ← Hardened rules with injection detection
├── firestore.indexes.json     ← 13 indexes for fast queries
├── functions/
│   ├── index.js               ← 22 functions (up from 15)
│   ├── blogGenerator.js       ← 120+ topics, internal links, AdSense injection
│   ├── internalLinking.js     ← NEW: Auto related content engine
│   ├── security.js            ← NEW: Rate limit + DDoS + WAF
│   ├── seedBlogs.js           ← NEW: Instant 100-blog seeder
│   ├── trending.js            ← Unchanged
│   ├── scraper.js             ← Unchanged
│   └── package.json           ← v4.0.0
└── public/
    ├── blog/
    │   └── index.html         ← Trending ticker + 11 filter cats + upgraded loader
    └── js/
        └── analytics.js       ← NEW: Full CTR + scroll + time tracking
```

---

## ❓ Troubleshooting

**Q: seedBlogs returns 403?**
A: Make sure `firebase functions:config:set seed.key="..."` matches your URL `?key=...`

**Q: Blogs not appearing on /blog/ page?**
A: Check Firestore console → blogs collection → status field = "published"

**Q: AI blog generation not working?**
A: Verify `firebase functions:config:get` shows `anthropic.key`. Function falls back to placeholder blogs automatically.

**Q: Rate limit errors?**
A: Normal for bots. Real users won't hit limits. Check `/securityStatus` for blocked IPs.
