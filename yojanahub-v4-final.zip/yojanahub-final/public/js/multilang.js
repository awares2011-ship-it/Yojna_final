// ================================================================
// YojanaHub Multilingual Engine v1.0
// Supported: hi, en, mr, bn, ta, te, gu, pa, kn, od
// ================================================================

const TRANSLATIONS = {
  hi: {
    nav_home: "होम", nav_schemes: "योजनाएं", nav_jobs: "नौकरी", nav_blog: "ब्लॉग",
    trending: "🔥 ट्रेंडिंग योजनाएं", search_ph: "योजना खोजें...",
    apply_now: "अभी Apply करें", read_more: "और पढ़ें",
    benefits: "फायदे", eligibility: "पात्रता", how_apply: "Apply कैसे करें",
    faq: "अक्सर पूछे जाने वाले सवाल", conclusion: "निष्कर्ष",
    share: "शेयर करें", subscribe: "Subscribe करें",
    all_schemes: "सभी योजनाएं", all_jobs: "सभी नौकरियां", all_blogs: "सभी Blogs",
  },
  en: {
    nav_home: "Home", nav_schemes: "Schemes", nav_jobs: "Jobs", nav_blog: "Blog",
    trending: "🔥 Trending Schemes", search_ph: "Search schemes...",
    apply_now: "Apply Now", read_more: "Read More",
    benefits: "Benefits", eligibility: "Eligibility", how_apply: "How to Apply",
    faq: "Frequently Asked Questions", conclusion: "Conclusion",
    share: "Share", subscribe: "Subscribe",
    all_schemes: "All Schemes", all_jobs: "All Jobs", all_blogs: "All Blogs",
  },
  mr: {
    nav_home: "मुख्यपृष्ठ", nav_schemes: "योजना", nav_jobs: "नोकरी", nav_blog: "ब्लॉग",
    trending: "🔥 ट्रेंडिंग योजना", search_ph: "योजना शोधा...",
    apply_now: "आत्ता अर्ज करा", read_more: "अधिक वाचा",
    benefits: "फायदे", eligibility: "पात्रता", how_apply: "अर्ज कसा करावा",
    faq: "वारंवार विचारले जाणारे प्रश्न", conclusion: "निष्कर्ष",
    share: "शेअर करा", subscribe: "सदस्यता घ्या",
    all_schemes: "सर्व योजना", all_jobs: "सर्व नोकऱ्या", all_blogs: "सर्व ब्लॉग",
  },
  bn: {
    nav_home: "হোম", nav_schemes: "প্রকল্প", nav_jobs: "চাকরি", nav_blog: "ব্লগ",
    trending: "🔥 ট্রেন্ডিং প্রকল্প", search_ph: "প্রকল্প খুঁজুন...",
    apply_now: "এখনই আবেদন করুন", read_more: "আরও পড়ুন",
    benefits: "সুবিধা", eligibility: "যোগ্যতা", how_apply: "কীভাবে আবেদন করবেন",
    faq: "প্রায়শই জিজ্ঞাসিত প্রশ্ন", conclusion: "উপসংহার",
    share: "শেয়ার করুন", subscribe: "সদস্যতা নিন",
    all_schemes: "সকল প্রকল্প", all_jobs: "সকল চাকরি", all_blogs: "সকল ব্লগ",
  },
  ta: {
    nav_home: "முகப்பு", nav_schemes: "திட்டங்கள்", nav_jobs: "வேலைகள்", nav_blog: "வலைப்பதிவு",
    trending: "🔥 பிரபலமான திட்டங்கள்", search_ph: "திட்டங்களை தேடுங்கள்...",
    apply_now: "இப்போதே விண்ணப்பிக்கவும்", read_more: "மேலும் படிக்கவும்",
    benefits: "நன்மைகள்", eligibility: "தகுதி", how_apply: "விண்ணப்பிப்பது எப்படி",
    faq: "அடிக்கடி கேட்கப்படும் கேள்விகள்", conclusion: "முடிவு",
    share: "பகிர்", subscribe: "சந்தா",
    all_schemes: "அனைத்து திட்டங்கள்", all_jobs: "அனைத்து வேலைகள்", all_blogs: "அனைத்து வலைப்பதிவுகள்",
  },
  te: {
    nav_home: "హోమ్", nav_schemes: "పథకాలు", nav_jobs: "ఉద్యోగాలు", nav_blog: "బ్లాగ్",
    trending: "🔥 ట్రెండింగ్ పథకాలు", search_ph: "పథకాలు వెతకండి...",
    apply_now: "ఇప్పుడే దరఖాస్తు చేయండి", read_more: "మరింత చదవండి",
    benefits: "ప్రయోజనాలు", eligibility: "అర్హత", how_apply: "దరఖాస్తు ఎలా చేయాలి",
    faq: "తరచుగా అడిగే ప్రశ్నలు", conclusion: "ముగింపు",
    share: "షేర్", subscribe: "సభ్యత్వం",
    all_schemes: "అన్ని పథకాలు", all_jobs: "అన్ని ఉద్యోగాలు", all_blogs: "అన్ని బ్లాగులు",
  },
  gu: {
    nav_home: "હોમ", nav_schemes: "યોજનાઓ", nav_jobs: "નોકરી", nav_blog: "બ્લૉગ",
    trending: "🔥 ટ્રેન્ડિંગ યોજનાઓ", search_ph: "યોજના શોધો...",
    apply_now: "હવે અરજી કરો", read_more: "વધુ વાંચો",
    benefits: "ફાયદા", eligibility: "પાત્રતા", how_apply: "અરજી કેવી રીતે કરવી",
    faq: "વારંવાર પૂછાતા પ્રશ્નો", conclusion: "નિષ્કર્ષ",
    share: "શેર", subscribe: "સબ્સ્ક્રાઇબ",
    all_schemes: "બધી યોજનાઓ", all_jobs: "બધી નોકરીઓ", all_blogs: "બધા બ્લૉગ",
  },
};

// Detect user language
function detectLanguage() {
  const urlLang = new URLSearchParams(location.search).get("lang");
  const stored  = localStorage.getItem("yh_lang");
  const browser = navigator.language?.split("-")[0];
  const langMap = { "hi":"hi","mr":"mr","bn":"bn","ta":"ta","te":"te","gu":"gu","pa":"pa","en":"en" };
  return urlLang || stored || langMap[browser] || "hi";
}

// Apply translations to page elements
function applyTranslations(lang) {
  const t = TRANSLATIONS[lang] || TRANSLATIONS["hi"];
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    if (t[key]) el.textContent = t[key];
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
    const key = el.getAttribute("data-i18n-placeholder");
    if (t[key]) el.placeholder = t[key];
  });
  document.documentElement.lang = lang;
  localStorage.setItem("yh_lang", lang);
}

// Auto-detect and apply on load
document.addEventListener("DOMContentLoaded", () => {
  const lang = detectLanguage();
  if (lang !== "hi") applyTranslations(lang);
});

// Expose for manual switching
window.YH_LANG = { applyTranslations, detectLanguage, TRANSLATIONS };
