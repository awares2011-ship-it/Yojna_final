// ================================================================
// /public/js/firebase-init.js — YojanaHub Firebase Client v3.0
// Trending, Analytics, View Tracking, Internal Linking
// ================================================================

const FIREBASE_CONFIG = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "kisanseva-ccfde.firebaseapp.com",
  projectId:         "kisanseva-ccfde",
  storageBucket:     "kisanseva-ccfde.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID",
};

let _db, _functions;
async function getFirebase() {
  if (_db) return;
  const { initializeApp, getApps } = await import("https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js");
  const { getFirestore, collection, query, where, orderBy, limit, getDocs, doc, getDoc, addDoc, serverTimestamp } = await import("https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js");
  const { getFunctions, httpsCallable } = await import("https://www.gstatic.com/firebasejs/10.12.0/firebase-functions.js");
  const app = getApps().length ? getApps()[0] : initializeApp(FIREBASE_CONFIG);
  _db        = getFirestore(app);
  _functions = getFunctions(app, "asia-south1");
  window._FB = { db:_db, fn:_functions, collection, query, where, orderBy, limit, getDocs, doc, getDoc, addDoc, serverTimestamp, httpsCallable };
}

// Page view
(async()=>{ try { await getFirebase(); const {addDoc,collection,serverTimestamp}=window._FB; await addDoc(collection(_db,"analytics"),{event:"pageview",page:location.pathname+location.search,referrer:document.referrer||"",createdAt:serverTimestamp()}); } catch(e){} })();

// Trending loader
async function loadTrendingSection(cid="trending-section") {
  const el = document.getElementById(cid); if(!el) return;
  try {
    await getFirebase();
    const {doc,getDoc}=window._FB;
    const snap = await getDoc(doc(_db,"cache","trending"));
    if(!snap.exists()) return;
    const t = snap.data();
    // Ticker
    const ticker = document.getElementById("news-ticker");
    if(ticker && t.breakingNews) {
      const html = t.breakingNews.map(n=>`<span class="ticker-item">${n}</span>`).join(" &nbsp;|&nbsp; ");
      ticker.innerHTML = `<div class="ticker-inner">${html} &nbsp;&nbsp; ${html}</div>`;
    }
    // Trending schemes
    const sg = document.getElementById("trending-schemes");
    if(sg && t.schemes) {
      sg.innerHTML = (t.schemes||[]).slice(0,6).map(s=>`<a href="/scheme.html?id=${s.id}" class="trend-card" data-track="ts-${s.id}"><span class="trend-fire">🔥</span><div class="trend-title">${s.title_hi||s.title_en}</div><div class="trend-meta">${s.category} · ${(s.views||0).toLocaleString("en-IN")} views</div></a>`).join("");
    }
    // Trending jobs
    const jg = document.getElementById("trending-jobs");
    if(jg && t.jobs) {
      jg.innerHTML = (t.jobs||[]).slice(0,4).map(j=>`<a href="/job.html?id=${j.id}" class="trend-card trend-job" data-track="tj-${j.id}"><span class="trend-fire">⚡</span><div class="trend-title">${j.title}</div><div class="trend-meta">${j.organization}</div></a>`).join("");
    }
    el.style.display="";
  } catch(e){ console.warn("Trending:",e.message); }
}

// View tracker
async function incrementView(col, id) {
  try { await getFirebase(); const {httpsCallable}=window._FB; await httpsCallable(_functions,"incrementView")({collectionName:col,docId:id}); } catch(e){}
}

// Internal link injector for blogs
async function injectInternalLinks() {
  const article = document.querySelector("article,.article");
  if(!article) return;
  try {
    await getFirebase();
    const {collection,query,orderBy,limit,getDocs}=window._FB;
    const snap = await getDocs(query(collection(_db,"schemes"),orderBy("views","desc"),limit(5)));
    const schemes = snap.docs.map(d=>({id:d.id,...d.data()}));
    const box = document.createElement("div");
    box.style.cssText="background:#f0fdf4;border:1px solid #86efac;border-radius:10px;padding:14px;margin:24px 0;";
    box.innerHTML = `<strong style="color:#166534;display:block;margin-bottom:8px">📎 संबंधित योजनाएं:</strong>${schemes.map(s=>`<a href="/scheme.html?id=${s.id}" style="display:inline-block;background:#fff;border:1px solid #bbf7d0;padding:3px 10px;border-radius:16px;margin:3px;font-size:.8rem;color:#166534;text-decoration:none;font-weight:600">${s.title_hi||s.title_en}</a>`).join("")}<br><a href="/scheme.html" style="color:#ea580c;font-weight:700;font-size:.82rem;display:inline-block;margin-top:8px">→ सभी योजनाएं देखें</a>`;
    const h2s = article.querySelectorAll("h2");
    if(h2s.length>=2) h2s[1].insertAdjacentElement("afterend",box);
  } catch(e){}
}

// Data loaders
async function loadSchemes(opts={}) {
  await getFirebase();
  const {collection,query,where,orderBy,limit,getDocs}=window._FB;
  const q=query(collection(_db,"schemes"),orderBy("views","desc"),limit(opts.pageSize||12));
  const snap=await getDocs(q);
  return snap.docs.map(d=>({id:d.id,...d.data(),_ref:d}));
}
async function loadJobs(opts={}) {
  await getFirebase();
  const {collection,query,where,orderBy,limit,getDocs}=window._FB;
  const q=query(collection(_db,"jobs"),orderBy("views","desc"),limit(opts.pageSize||12));
  const snap=await getDocs(q);
  return snap.docs.map(d=>({id:d.id,...d.data()}));
}
async function loadBlogs(opts={}) {
  await getFirebase();
  const {collection,query,where,orderBy,limit,getDocs}=window._FB;
  const q=query(collection(_db,"blogs"),where("status","==","published"),orderBy("createdAt","desc"),limit(opts.pageSize||9));
  const snap=await getDocs(q);
  return snap.docs.map(d=>({id:d.id,...d.data()}));
}
async function loadBlogBySlug(slug) {
  await getFirebase();
  const {collection,query,where,limit,getDocs}=window._FB;
  const q=query(collection(_db,"blogs"),where("slug","==",slug),where("status","==","published"),limit(1));
  const snap=await getDocs(q);
  if(snap.empty) return null;
  const d=snap.docs[0]; return {id:d.id,...d.data()};
}
async function saveLead(name,mobile,interest="general") {
  await getFirebase();
  return window._FB.httpsCallable(_functions,"saveLead")({name,mobile,interest});
}
async function searchAll(q) {
  const r=await fetch(`https://us-central1-kisanseva-ccfde.cloudfunctions.net/search?q=${encodeURIComponent(q)}`);
  return r.json();
}

// Auto-init
document.addEventListener("DOMContentLoaded",()=>{
  const p=location.pathname;
  if(p==="/"||p==="/index.html") loadTrendingSection("trending-section");
  if(p.includes("/blog/")&&p!=="/blog/"&&!p.endsWith("/")) {
    injectInternalLinks();
    const slug=p.split("/blog/")[1].replace(".html","");
    if(slug) loadBlogBySlug(slug).then(b=>{ if(b) incrementView("blogs",b.id); });
  }
  if(p.includes("/scheme.html")){ const id=new URLSearchParams(location.search).get("id"); if(id) incrementView("schemes",id); }
  if(p.includes("/job.html")){ const id=new URLSearchParams(location.search).get("id"); if(id) incrementView("jobs",id); }
});

window.YH={loadSchemes,loadJobs,loadBlogs,loadBlogBySlug,loadTrendingSection,incrementView,saveLead,searchAll,injectInternalLinks,getFirebase};
