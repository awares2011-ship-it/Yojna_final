// ================================================================
// /public/js/analytics.js — YojanaHub Analytics Engine v2.0
// Tracks: pageviews, clicks, scroll depth, time-on-page, CTR
// Writes to Firestore analytics collection via Firebase callable
// ================================================================

(function() {
  "use strict";

  const PAGE   = window.location.pathname + window.location.search;
  const REF    = document.referrer || "direct";
  const UA     = navigator.userAgent || "";
  let _firebase, _fn;

  // Wait for Firebase to be ready
  function waitForFirebase(cb, tries = 0) {
    if (tries > 20) return;
    if (window.firebase && window.firebase.functions) {
      _firebase = window.firebase;
      _fn       = _firebase.functions();
      cb();
    } else {
      setTimeout(() => waitForFirebase(cb, tries + 1), 300);
    }
  }

  // ── Track pageview ────────────────────────────────────────────
  function trackPageView() {
    const data = {
      event:    "pageview",
      page:     PAGE.substring(0, 200),
      referrer: REF.substring(0, 200),
      ua:       UA.substring(0, 200),
      category: detectCategory(),
    };
    safeCall("trackUserActivity", data);
  }

  // ── Track clicks on scheme/job/blog cards ─────────────────────
  function setupClickTracking() {
    document.addEventListener("click", function(e) {
      const el = e.target.closest("[data-track-id]");
      if (!el) return;
      const coll = el.getAttribute("data-track-collection") || "";
      const id   = el.getAttribute("data-track-id") || "";
      const src  = el.getAttribute("data-track-source") || "card_click";
      if (!coll || !id) return;
      safeCall("trackClick", { collectionName: coll, docId: id, source: src });
    });

    // Track internal link clicks (blog-to-blog)
    document.addEventListener("click", function(e) {
      const link = e.target.closest("a[href^='/blog/']");
      if (!link) return;
      safeCall("trackUserActivity", {
        event:    "internal_link_click",
        page:     PAGE.substring(0, 200),
        referrer: link.href.substring(0, 200),
        ua:       "",
        category: "internal",
      });
    });
  }

  // ── Track scroll depth ────────────────────────────────────────
  let maxScroll = 0;
  let scrollSent = { 25: false, 50: false, 75: false, 100: false };

  function trackScroll() {
    const scrolled = Math.round(
      (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100
    );
    if (scrolled > maxScroll) maxScroll = scrolled;
    [25, 50, 75, 100].forEach(threshold => {
      if (maxScroll >= threshold && !scrollSent[threshold]) {
        scrollSent[threshold] = true;
        safeCall("trackUserActivity", {
          event:    `scroll_${threshold}`,
          page:     PAGE.substring(0, 200),
          referrer: "",
          ua:       "",
          category: "engagement",
        });
      }
    });
  }

  // ── Track time on page ────────────────────────────────────────
  const startTime = Date.now();
  function trackTimeOnPage() {
    const duration = Math.round((Date.now() - startTime) / 1000);
    if (duration < 5) return;
    safeCall("trackUserActivity", {
      event:    "time_on_page",
      page:     PAGE.substring(0, 200),
      duration: duration,
      referrer: "",
      ua:       "",
      category: "engagement",
    });
  }

  // ── Detect page category ──────────────────────────────────────
  function detectCategory() {
    const p = PAGE.toLowerCase();
    if (p.includes("/blog/"))     return "blog";
    if (p.includes("scheme"))     return "scheme";
    if (p.includes("job"))        return "job";
    if (p.includes("state/"))     return "state";
    if (p.includes("category/"))  return "category";
    if (p === "/" || p === "")    return "home";
    return "other";
  }

  // ── Update trending data display ──────────────────────────────
  async function loadTrendingData() {
    const el = document.getElementById("trending-ticker");
    const trendSection = document.getElementById("trending-section");
    if (!el && !trendSection) return;

    try {
      const resp = await fetch("/api/trending", {
        headers: { "Accept": "application/json" },
      });
      if (!resp.ok) return;
      const data = await resp.json();

      // Update breaking news ticker
      if (el && data.breakingNews && data.breakingNews.length) {
        const items = data.breakingNews.map(n =>
          `<span style="margin-right:60px;">${n}</span>`
        ).join("");
        el.innerHTML = items + items; // Double for continuous loop
      }

      // Update trending section
      if (trendSection && data.blogs && data.blogs.length) {
        const cards = data.blogs.slice(0, 4).map(b =>
          `<a href="/blog/${b.slug}.html"
              style="display:block;padding:8px 12px;background:#fff;border-radius:8px;
                     border:1px solid #e5e7eb;text-decoration:none;color:#111827;
                     font-size:.85rem;font-weight:600;margin-bottom:8px;"
              data-track-collection="blogs" data-track-id="${b.id}" data-track-source="trending_section">
            🔥 ${b.title}
          </a>`
        ).join("");
        trendSection.innerHTML = cards;
      }
    } catch (_) {
      // Silent fail — trending is non-critical
    }
  }

  // ── Safe Firebase call (no crash if Firebase not loaded) ──────
  function safeCall(fnName, data) {
    try {
      if (!_fn) return;
      const fn = _fn.httpsCallable(fnName);
      fn(data).catch(() => {}); // Fire and forget
    } catch (_) {}
  }

  // ── Initialize ────────────────────────────────────────────────
  waitForFirebase(() => {
    trackPageView();
    setupClickTracking();

    // Scroll tracking (throttled)
    let scrollTimer;
    window.addEventListener("scroll", () => {
      clearTimeout(scrollTimer);
      scrollTimer = setTimeout(trackScroll, 200);
    }, { passive: true });

    // Time on page (on unload)
    window.addEventListener("beforeunload", trackTimeOnPage);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") trackTimeOnPage();
    });

    // Load trending data
    loadTrendingData();
  });

  // ── Expose for manual calls from HTML ─────────────────────────
  window.YHAnalytics = {
    trackClick: (coll, id, src) => safeCall("trackClick", { collectionName: coll, docId: id, source: src }),
    trackEvent: (event, page, cat) => safeCall("trackUserActivity", { event, page: page || PAGE, ua: "", referrer: "", category: cat || "manual" }),
  };

})();
