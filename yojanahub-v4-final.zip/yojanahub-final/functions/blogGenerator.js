// ================================================================
// /functions/blogGenerator.js — YojanaHub Auto Blog Generator v4.0
// 200+ HIGH CPC topics | Internal linking | AI content | 1500-2000 words
// ================================================================
"use strict";

const admin = require("firebase-admin");
const axios  = require("axios");
const db     = admin.firestore();

const BLOG_TOPICS = [
  // LOANS — Very High CPC
  { title:"Mudra Loan 2026 – Business ke liye 10 Lakh Apply Karen",          kws:["mudra loan apply 2026","govt business loan","loan schemes india"], cat:"Loan" },
  { title:"PMEGP Loan 2026 – Manufacturing ke liye 35% Subsidy Paye",        kws:["pmegp loan","manufacturing subsidy india","govt subsidy business"], cat:"Loan" },
  { title:"SBI E-Mudra Instant Loan 2026 – 59 Minutes mein Approval",        kws:["sbi mudra loan","instant business loan","loan schemes india"], cat:"Loan" },
  { title:"StandUp India 1 Crore Loan – SC ST Women Guide 2026",             kws:["standup india loan","sc st loan","women business loan india"], cat:"Loan" },
  { title:"Kisan Credit Card 2026 – 3 Lakh 4% Interest Apply Kare",          kws:["kisan credit card 2026","kcc loan","kisan loan yojana"], cat:"Loan" },
  { title:"PM SVANidhi Loan 2026 – Street Vendors 50000 Loan Guide",         kws:["svanidhi loan","street vendor loan","govt loan vendors"], cat:"Loan" },
  { title:"Education Loan Government Scheme 2026 – 0% Interest Guide",       kws:["education loan govt","student loan india","scholarship 2026"], cat:"Loan" },
  { title:"NABARD Agricultural Loan 2026 – Kisan Complete Guide",            kws:["nabard loan","agricultural loan india","kisan loan yojana"], cat:"Loan" },
  { title:"Gold Loan vs Mudra Loan 2026 – Which is Better for Business?",    kws:["gold loan vs mudra loan","business loan comparison","loan schemes india"], cat:"Loan" },
  { title:"Home Loan Government Subsidy 2026 – PMAY CLSS 2.67 Lakh",        kws:["pmay home loan subsidy","housing loan subsidy","loan schemes india"], cat:"Loan" },
  { title:"Personal Loan Without CIBIL Score 2026 – Bank List India",        kws:["personal loan no cibil","loan without credit score","bad credit loan india"], cat:"Loan" },
  { title:"Business Loan Without CIBIL 2026 – 5 Lakh Instant Approve",      kws:["business loan no cibil 2026","loan bad cibil score","instant business loan"], cat:"Loan" },
  { title:"No CIBIL Loan 2026 – Sarkari Bank se 2 Lakh Kaise Le?",          kws:["no cibil loan india","bina cibil loan","govt bank loan no cibil"], cat:"Loan" },
  { title:"CIBIL Score 550 par Loan 2026 – Kaun se Bank Dete Hain?",        kws:["loan on cibil 550","low cibil score loan india","bad cibil loan 2026"], cat:"Loan" },
  { title:"Startup India Seed Fund Loan 2026 – 20 Lakh Govt Support",       kws:["startup india loan","seed fund india","govt startup scheme 2026"], cat:"Loan" },
  { title:"Women Entrepreneur Loan 2026 – Mahila Udyam Nidhi 10 Lakh",      kws:["women entrepreneur loan","mahila udyam nidhi","women business loan india"], cat:"Loan" },
  { title:"Vehicle Loan Subsidy Government 2026 – EV Scheme Guide",          kws:["vehicle loan subsidy","ev loan govt scheme","electric vehicle loan india"], cat:"Loan" },
  { title:"Solar Panel Loan 2026 – MNRE 40% Subsidy Bank Loan Apply",       kws:["solar panel loan","solar subsidy loan india","mnre solar scheme 2026"], cat:"Loan" },
  { title:"Micro Finance Loan 2026 – SHG Mahila 1 Lakh Without Collateral", kws:["micro finance loan india","shg loan 2026","mahila micro loan"], cat:"Loan" },
  { title:"PM Rozgar Loan 2026 – Unemployed Youth ke liye 25 Lakh",         kws:["pm rozgar loan","youth employment loan india","govt loan unemployed"], cat:"Loan" },
  { title:"Two Wheeler Loan Government Scheme 2026 – 0 Down Payment",       kws:["2 wheeler govt loan 2026","bike loan subsidy india","two wheeler scheme"], cat:"Loan" },

  // INSURANCE — High CPC
  { title:"PM Jeevan Jyoti Bima 2026 – 2 Lakh Life Insurance 436 per Year",  kws:["pm jeevan jyoti bima","life insurance scheme india","insurance schemes india"], cat:"Insurance" },
  { title:"PM Suraksha Bima 2026 – 2 Lakh Accident Insurance 20 per Year",   kws:["pm suraksha bima","accident insurance india","insurance schemes india"], cat:"Insurance" },
  { title:"Ayushman Bharat 2026 – 5 Lakh Free Health Insurance Apply",       kws:["ayushman bharat 2026","pmjay insurance","free health insurance india"], cat:"Insurance" },
  { title:"Atal Pension Yojana 2026 – 5000 per Month Retirement Plan",       kws:["atal pension yojana 2026","apy pension","insurance schemes india"], cat:"Insurance" },
  { title:"PM Fasal Bima 2026 – Kisan Fasal Insurance Complete Guide",       kws:["pm fasal bima","crop insurance india","insurance schemes india"], cat:"Insurance" },
  { title:"LIC Aadhaar Shila Policy 2026 – Women ke liye Best Insurance",    kws:["lic aadhaar shila","women insurance","insurance schemes india"], cat:"Insurance" },
  { title:"Post Office Savings Scheme 2026 – Highest Interest Rate Plans",   kws:["post office savings","nsc interest rate","insurance schemes india"], cat:"Insurance" },
  { title:"Senior Citizen Savings Scheme 2026 – 8.2% Interest Rate",        kws:["scss 2026","senior citizen scheme","post office scheme","insurance schemes india"], cat:"Insurance" },
  { title:"Health Insurance Government Scheme 2026 – Free 5 Lakh Cover",    kws:["health insurance govt india","free health cover 2026","pmjay eligibility"], cat:"Insurance" },
  { title:"Crop Insurance PMFBY 2026 – Rabi Kharif Season Full Guide",      kws:["pmfby crop insurance 2026","rabi insurance india","kharif insurance scheme"], cat:"Insurance" },
  { title:"Life Insurance vs Term Insurance 2026 – Kaun sa Le?",            kws:["life vs term insurance india","best insurance 2026","lic term plan"], cat:"Insurance" },
  { title:"ESIC Health Insurance 2026 – Employee ke liye Free Coverage",     kws:["esic insurance 2026","employee health insurance india","esi scheme benefits"], cat:"Insurance" },
  { title:"Pradhan Mantri Bima Yojana 2026 – PMJJBY and PMSBY Details",     kws:["pradhan mantri bima yojana","govt bima 2026","insurance schemes india"], cat:"Insurance" },
  { title:"Animal Husbandry Insurance 2026 – Pashu Bima Yojana Guide",      kws:["animal insurance india 2026","pashu bima","livestock insurance scheme"], cat:"Insurance" },

  // SUBSIDY PROGRAMS — High CPC
  { title:"PM Surya Ghar 2026 – Free Solar Electricity Apply Online",       kws:["pm surya ghar","solar scheme india","free electricity scheme"], cat:"Subsidy" },
  { title:"PM Ujjwala Yojana 2.0 – Free LPG Connection Apply 2026",        kws:["ujjwala yojana","free lpg connection","women scheme india"], cat:"Subsidy" },
  { title:"PM Vishwakarma Yojana 2026 – 3 Lakh Loan Plus Free Training",   kws:["pm vishwakarma","artisan loan 2026","govt subsidy business"], cat:"Subsidy" },
  { title:"PM Awas Yojana Gramin 2026 – 1.3 Lakh Free House Apply",        kws:["pmay gramin 2026","rural housing scheme","free house govt india"], cat:"Subsidy" },
  { title:"Solar Rooftop Subsidy 2026 – 78000 Subsidy How to Apply",       kws:["solar rooftop subsidy 2026","solar panel subsidy india","mnre rooftop scheme"], cat:"Subsidy" },
  { title:"EV Subsidy FAME 2026 – Electric Vehicle 1.5 Lakh Discount",     kws:["ev subsidy india 2026","fame scheme electric vehicle","ev discount govt"], cat:"Subsidy" },
  { title:"Fertilizer Subsidy 2026 – Kisan ko Kitna Milta Hai?",           kws:["fertilizer subsidy india 2026","urvarak subsidy","kisan fertilizer scheme"], cat:"Subsidy" },
  { title:"Drip Irrigation Subsidy 2026 – PMKSY 55% Govt Grant Guide",     kws:["drip irrigation subsidy 2026","pmksy irrigation scheme","micro irrigation india"], cat:"Subsidy" },
  { title:"Free Toilet Scheme 2026 – Swachh Bharat 12000 Apply Now",       kws:["swachh bharat toilet scheme","free toilet govt 2026","toilet subsidy india"], cat:"Subsidy" },
  { title:"Skill Development Subsidy 2026 – PMKVY Free Training 8000",     kws:["pmkvy subsidy 2026","skill development free training","vocational training india"], cat:"Subsidy" },
  { title:"Biogas Subsidy 2026 – GOBAR-DHAN Scheme 40000 Grant",           kws:["biogas subsidy india","gobar dhan scheme 2026","rural energy subsidy"], cat:"Subsidy" },
  { title:"Greenhouse Farming Subsidy 2026 – NHM 50% Grant for Farmers",   kws:["greenhouse subsidy india 2026","nhm greenhouse scheme","protected cultivation subsidy"], cat:"Subsidy" },
  { title:"PM KUSUM Solar Scheme 2026 – Farmer 90% Subsidy Apply",         kws:["pm kusum 2026","solar pump subsidy farmer","kusum scheme apply"], cat:"Subsidy" },
  { title:"Har Ghar Bijli 2026 – Free Electricity 200 Units Scheme",       kws:["har ghar bijli 2026","free electricity 200 units","saubhagya scheme india"], cat:"Subsidy" },

  // GOVT FUNDING SCHEMES
  { title:"Jan Dhan Yojana 2026 – 10000 Overdraft Plus Free Insurance",     kws:["jan dhan yojana","zero balance account","financial inclusion"], cat:"Government Scheme" },
  { title:"E-Shram Card 2026 – 2 Lakh Insurance Plus Register Online",      kws:["e shram card","unorganized worker scheme","labour insurance"], cat:"Government Scheme" },
  { title:"NREGA Job Card 2026 – 100 Days Work 267 per Day Apply",          kws:["nrega job card","mgnrega 2026","rural employment guarantee"], cat:"Government Scheme" },
  { title:"PM Garib Kalyan Yojana 2026 – Free Ration Plus Benefits Guide",  kws:["pm garib kalyan yojana 2026","free ration scheme","pmgky benefits"], cat:"Government Scheme" },
  { title:"Atal Innovation Mission 2026 – Startup 1 Crore Funding",         kws:["atal innovation mission 2026","aim startup funding","niti aayog startup"], cat:"Government Scheme" },
  { title:"DBT Direct Benefit Transfer 2026 – Subsidy Direct Khate Mein",   kws:["dbt 2026","direct benefit transfer india","subsidy to bank account"], cat:"Government Scheme" },
  { title:"National Social Assistance 2026 – NSAP Pension 3000 per Month",  kws:["nsap pension 2026","national social assistance india","old age pension scheme"], cat:"Government Scheme" },
  { title:"Jal Jeevan Mission 2026 – Har Ghar Jal Water Connection",        kws:["jal jeevan mission 2026","har ghar jal scheme","water scheme india"], cat:"Government Scheme" },
  { title:"Digital India Scheme 2026 – Free WiFi Plus Digital Training",     kws:["digital india 2026","free wifi scheme india","digital training govt"], cat:"Government Scheme" },
  { title:"PM Kaushal Vikas Yojana 2026 – Free Job Training Certificate",   kws:["pmkvy 2026","free skill training india","govt job training certificate"], cat:"Government Scheme" },

  // FARMER SCHEMES — Very High CPC
  { title:"Kisan Loan Yojana 2026 – Sabhi Schemes ki Complete List",        kws:["kisan loan yojana","kisan loan 2026","farmer loan india"], cat:"Farmer" },
  { title:"PM Kisan 20th Installment 2026 – Status Check Plus Date",        kws:["pm kisan 20th installment","pm kisan status","kisan loan yojana"], cat:"Farmer" },
  { title:"PM Kisan eKYC 2026 – Mobile se Kaise Karen? Step by Step",       kws:["pm kisan ekyc","kisan kyc update","kisan loan yojana"], cat:"Farmer" },
  { title:"Kisan Drone Subsidy 2026 – Drone ke liye 50% Govt Grant",        kws:["kisan drone subsidy 2026","farmer drone scheme india","drone subsidy apply"], cat:"Farmer" },
  { title:"Krishi Sinchai Yojana 2026 – Khet Tak Pani Plus Subsidy Guide",  kws:["pmksy 2026","krishi sinchai yojana","irrigation scheme india"], cat:"Farmer" },
  { title:"Soil Health Card 2026 – Muft Soil Testing Plus Subsidy",         kws:["soil health card 2026","soil testing scheme india","kisan soil card"], cat:"Farmer" },
  { title:"eNAM Market Platform 2026 – Kisan Online Crop Sell Karen",        kws:["enam platform 2026","online crop selling india","kisan market scheme"], cat:"Farmer" },
  { title:"PM Kisan Mandhan Pension 2026 – 3000 per Month at 60 Years",     kws:["pm kisan mandhan 2026","farmer pension scheme india","kisan pension apply"], cat:"Farmer" },
  { title:"Organic Farming Scheme 2026 – PKVY 50000 per Ha Subsidy",        kws:["organic farming subsidy 2026","pkvy scheme india","organic farming india"], cat:"Farmer" },
  { title:"Fisherman Scheme 2026 – PM Matsya Sampada 20000 Crore",          kws:["pm matsya sampada 2026","fisherman scheme india","fish farming loan"], cat:"Farmer" },
  { title:"Dairy Farming Loan 2026 – NABARD Dairy Scheme 7 Lakh",           kws:["dairy farming loan 2026","nabard dairy scheme","cow buffalo loan india"], cat:"Farmer" },
  { title:"Poultry Farm Loan 2026 – Government Subsidy 3 Lakh Guide",       kws:["poultry farm loan 2026","poultry subsidy india","backyard poultry scheme"], cat:"Farmer" },
  { title:"Agricultural Equipment Subsidy 2026 – Tractor 50% Discount",     kws:["tractor subsidy 2026","agricultural equipment scheme","kisan tractor loan"], cat:"Farmer" },

  // JOBS/NAUKRI — Very High CPC
  { title:"Sarkari Yojana 2026 – Top 20 Schemes You Must Know",             kws:["sarkari yojana 2026","govt scheme hindi","sarkari yojana"], cat:"Government Scheme" },
  { title:"Sarkari Naukri 2026 – Top 10 Upcoming Bharti Apply Karen",       kws:["sarkari naukri 2026","govt job apply","latest govt jobs india"], cat:"Jobs" },
  { title:"SSC CGL 2026 – Complete Exam Guide Salary 1.5 Lakh per Month",   kws:["ssc cgl 2026","ssc cgl exam guide","central govt graduate job"], cat:"Jobs" },
  { title:"Railway NTPC 2026 – 11558 Posts Apply Now",                       kws:["rrb ntpc 2026","railway job apply","sarkari naukri 2026"], cat:"Jobs" },
  { title:"IBPS PO 2026 – Bank Job Apply Salary 52000 per Month",           kws:["ibps po 2026","bank job apply","banking exam 2026"], cat:"Jobs" },
  { title:"Agniveer 2026 – Army Navy Air Force Apply Complete Guide",        kws:["agniveer 2026","agnipath scheme","defence job apply"], cat:"Jobs" },
  { title:"RRB Group D 2026 – 32000 Posts 10th Pass Apply",                 kws:["rrb group d 2026","railway group d","10th pass govt job"], cat:"Jobs" },
  { title:"UP Police Constable 2026 – 60244 Vacancy Complete Guide",        kws:["up police 2026","police constable up","state police job"], cat:"Jobs" },
  { title:"UPSC 2026 – IAS Exam Preparation Complete Strategy Guide",       kws:["upsc 2026","ias exam guide","civil services preparation"], cat:"Jobs" },
  { title:"SSC GD Constable 2026 – 45000 Posts Salary Benefits",            kws:["ssc gd 2026","constable job 2026","10th pass central job"], cat:"Jobs" },
  { title:"BPSC 2026 – Bihar PCS Exam Guide Plus Salary Details",           kws:["bpsc 2026","bihar pcs exam","state pcs job"], cat:"Jobs" },
  { title:"NDA 2026 – Defence Exam 12th Pass 56000 Salary Guide",           kws:["nda exam 2026","defence exam 12th pass","army officer job india"], cat:"Jobs" },
  { title:"Post Office Job 2026 – GDS 30000 Posts Apply 10th Pass",         kws:["post office job 2026","gds recruitment","postal job india"], cat:"Jobs" },
  { title:"CRPF Constable 2026 – 9000 Posts 10th Pass Complete Guide",      kws:["crpf constable 2026","crpf recruitment","paramilitary job india"], cat:"Jobs" },
  { title:"Anganwadi Worker Job 2026 – State-wise Vacancy Plus Salary",     kws:["anganwadi job 2026","anganwadi recruitment india","anganwadi salary"], cat:"Jobs" },
  { title:"Sarkari Naukri Without Exam 2026 – Direct Recruitment Guide",    kws:["sarkari naukri without exam","direct recruitment india","no exam govt job 2026"], cat:"Jobs" },
  { title:"SBI Clerk 2026 – SBI 13735 Posts Apply Complete Guide",          kws:["sbi clerk 2026","sbi recruitment","bank job 12th pass"], cat:"Jobs" },
  { title:"Haryana CET 2026 – Common Eligibility Test Apply Guide",         kws:["haryana cet 2026","haryana sarkari naukri","state cet exam guide"], cat:"Jobs" },

  // EDUCATION/SCHOLARSHIP
  { title:"National Scholarship 2026 – NSP Portal 75000 Apply Now",         kws:["national scholarship 2026","nsp portal scholarship","govt scholarship india"], cat:"Education" },
  { title:"PM Scholarship 2026 – 25000 per Year for IIT NIT Students",      kws:["pm scholarship 2026","pm scholarship scheme","student scholarship india"], cat:"Education" },
  { title:"Free Coaching Scheme 2026 – Minorities ke liye UPSC IIT Prep",   kws:["free coaching scheme 2026","minority coaching india","neet free coaching"], cat:"Education" },
  { title:"SC ST Scholarship 2026 – Pre Post Matric 1 Lakh Benefits",       kws:["sc st scholarship 2026","pre post matric scholarship","dalit scholarship india"], cat:"Education" },
  { title:"OBC Scholarship 2026 – 12000 per Year Apply NSP Portal",         kws:["obc scholarship 2026","other backward class scholarship","obc student benefit"], cat:"Education" },
  { title:"AICTE Scholarship 2026 – Engineering Students 50000 per Year",   kws:["aicte scholarship 2026","engineering scholarship india","technical scholarship"], cat:"Education" },

  // WOMEN SCHEMES
  { title:"Beti Bachao Beti Padhao 2026 – Cash Incentive Plus Scholarship", kws:["beti bachao","girl child scheme","women scheme india"], cat:"Women" },
  { title:"Sukanya Samriddhi Yojana 2026 – 64 Lakh Return Calculator",      kws:["sukanya samriddhi 2026","ssy calculator","girl child investment"], cat:"Women" },
  { title:"Mahila Samman Savings Certificate 2026 – 7.5% Interest",         kws:["mahila samman savings 2026","women savings scheme india","mahila samman"], cat:"Women" },
  { title:"PM Matru Vandana Yojana 2026 – 6000 Pregnant Women Cash",        kws:["matru vandana yojana 2026","pmmvy scheme","pregnant women scheme india"], cat:"Women" },
  { title:"Women SHG Loan 2026 – Lakhpati Didi Scheme 5 Lakh Free",        kws:["women shg loan 2026","lakhpati didi scheme","women self help group loan"], cat:"Women" },
  { title:"Free Silai Machine 2026 – PM Vishwakarma Women Apply Now",       kws:["free silai machine 2026","sewing machine scheme india","women scheme 2026"], cat:"Women" },
  { title:"Widow Pension Scheme 2026 – State-wise 2500 per Month List",     kws:["widow pension 2026","vidhwa pension scheme india","widow benefit india"], cat:"Women" },
  { title:"Stree Shakti Loan 2026 – SBI Women Entrepreneur 25 Lakh",        kws:["stree shakti loan","sbi women loan","women entrepreneur india"], cat:"Women" },
  { title:"MP Ladli Behna Yojana 2026 – 1250 per Month Apply Guide",        kws:["ladli behna yojana","mp govt women scheme","mp scheme 2026"], cat:"Women" },

  // HOUSING
  { title:"PM Awas Yojana Urban 2026 – 2.5 Lakh Subsidy Apply Now",        kws:["pmay urban 2026","pm awas yojana city","housing scheme urban india"], cat:"Housing" },
  { title:"SBI Home Loan Subsidy 2026 – 2.67 Lakh PMAY CLSS Guide",        kws:["sbi home loan subsidy 2026","pmay clss 2026","home loan subsidy india"], cat:"Housing" },
  { title:"PM Awas Yojana List 2026 – Naam Kaise Check Karen?",             kws:["pmay list 2026","pm awas list check","awas yojana suchi"], cat:"Housing" },

  // FINANCE/INVESTMENT
  { title:"PPF vs NPS vs SSY – Best Investment for 2026 Returns",           kws:["ppf vs nps","best investment india 2026","tax saving scheme"], cat:"Finance" },
  { title:"Income Tax Saving Schemes 2026 – 1.5 Lakh 80C Deduction",       kws:["income tax saving 2026","80c deduction india","tax save scheme india"], cat:"Finance" },
  { title:"Fixed Deposit vs Post Office 2026 – Where to Invest?",           kws:["fd vs post office 2026","best fd india 2026","post office interest 2026"], cat:"Finance" },
  { title:"SGB Sovereign Gold Bond 2026 – 2.5% Extra Interest Guide",       kws:["sovereign gold bond 2026","sgb investment india","gold investment scheme"], cat:"Finance" },
  { title:"NPS National Pension System 2026 – Tax Free 2 Lakh Invest",     kws:["nps 2026","national pension system india","nps tax benefit"], cat:"Finance" },

  // HEALTH
  { title:"Ayushman Card Download 2026 – Mobile se 5 Minute mein",          kws:["ayushman card download 2026","pmjay card online","ayushman card kaise banaye"], cat:"Health" },
  { title:"Jan Aushadhi Kendra 2026 – 90% Cheap Medicines Near You",        kws:["jan aushadhi kendra 2026","cheap medicines govt","pm jan aushadhi scheme"], cat:"Health" },
  { title:"Free Cancer Treatment Scheme 2026 – CGHS Plus AIIMS Guide",      kws:["free cancer treatment india 2026","cancer scheme india","cghs cancer treatment"], cat:"Health" },
  { title:"Janani Suraksha Yojana 2026 – 1400 Delivery Cash Guide",         kws:["janani suraksha yojana 2026","jsy scheme india","delivery cash scheme india"], cat:"Health" },
  { title:"Dialysis Free Scheme 2026 – PMNDP Kidney Patient Guide",         kws:["free dialysis scheme 2026","pmndp scheme","kidney treatment free india"], cat:"Health" },

  // BUSINESS/MSME
  { title:"MSME Registration 2026 – Udyam Certificate Benefits 15 Lakh",    kws:["msme registration 2026","udyam certificate benefits","msme loan india"], cat:"Business" },
  { title:"CGTMSE Loan 2026 – MSME 5 Crore Without Collateral",             kws:["cgtmse loan 2026","msme collateral free loan","govt guarantee loan business"], cat:"Business" },
  { title:"GeM Registration 2026 – Govt Marketplace Seller Guide",           kws:["gem portal 2026","gem seller registration","govt marketplace india"], cat:"Business" },
  { title:"SIDBI Loan 2026 – Small Industry 25 Crore Low Rate Apply",       kws:["sidbi loan 2026","small industry loan india","sidbi scheme 2026"], cat:"Business" },
  { title:"ODOP One District One Product 2026 – 25 Lakh Funding Guide",     kws:["odop scheme 2026","one district one product india","local product scheme"], cat:"Business" },
  { title:"ZED Certification 2026 – Quality Upgrade 5 Lakh Subsidy",        kws:["zed certification 2026","zero effect zero defect scheme","msme quality upgrade"], cat:"Business" },

  // STATE-SPECIFIC
  { title:"Maharashtra Scheme 2026 – MahaSwayam Portal Jobs Plus Schemes",  kws:["maharashtra scheme 2026","mahaswayam portal","maharashtra govt job"], cat:"Government Scheme" },
  { title:"UP Scheme 2026 – CM Yogi Best 10 Schemes for UP Residents",      kws:["up scheme 2026","cm yogi scheme","uttar pradesh govt scheme"], cat:"Government Scheme" },
  { title:"Rajasthan Scheme 2026 – Chiranjeevi Health Plus Benefits",        kws:["rajasthan scheme 2026","chiranjeevi yojana","rajasthan govt scheme"], cat:"Government Scheme" },
  { title:"Bihar Scheme 2026 – Mukhyamantri Cycle Plus Women Scheme",       kws:["bihar scheme 2026","mukhyamantri cycle yojana","bihar govt scheme 2026"], cat:"Government Scheme" },
  { title:"Gujarat iKhedut Portal 2026 – Farmer Subsidy Complete List",     kws:["gujarat scheme 2026","ikhedut portal","gujarat farmer subsidy"], cat:"Farmer" },
  { title:"Karnataka Shakti Yojana 2026 – Free Bus for Women Guide",        kws:["karnataka scheme 2026","shakti yojana bus","karnataka women scheme"], cat:"Women" },
  { title:"Odisha KALIA Scheme 2026 – Farmer 10000 Complete Guide",         kws:["odisha scheme 2026","kalia scheme odisha","odisha farmer scheme"], cat:"Farmer" },
];

// ── Slugify ──────────────────────────────────────────────────────
function slugify(text) {
  return text.toLowerCase().replace(/[^\w\s-]/g,"").replace(/[\s_-]+/g,"-").replace(/^-+|-+$/g,"").substring(0,80);
}

// ── Internal Links HTML ──────────────────────────────────────────
function buildInternalLinksHTML(topic, relatedTopics=[]) {
  const mainLink = ["Jobs"].includes(topic.cat) ? "/job.html" : "/scheme.html";
  const related = relatedTopics.slice(0,4).map(t =>
    `<li><a href="/blog/${slugify(t.title)}.html" style="color:#16a34a;font-weight:600;">${t.title}</a></li>`
  ).join("\n");
  return `<div style="background:#f0fdf4;border:2px solid #bbf7d0;border-radius:12px;padding:24px;margin:32px 0;">
<h3 style="color:#166534;font-size:1.1rem;font-weight:800;margin-bottom:14px;">Related Guides</h3>
<ul style="list-style:none;padding:0;margin:0 0 16px;display:grid;gap:10px;">${related}</ul>
<div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:14px;">
<a href="${mainLink}" style="background:#16a34a;color:#fff;text-decoration:none;padding:8px 18px;border-radius:8px;font-weight:700;font-size:.85rem;">All Schemes</a>
<a href="/job.html" style="background:#ea580c;color:#fff;text-decoration:none;padding:8px 18px;border-radius:8px;font-weight:700;font-size:.85rem;">Govt Jobs</a>
<a href="/blog/" style="background:#1d4ed8;color:#fff;text-decoration:none;padding:8px 18px;border-radius:8px;font-weight:700;font-size:.85rem;">More Blogs</a>
</div></div>`;
}

// ── AdSense Placement HTML ───────────────────────────────────────
function buildAdSenseHTML(slot="MID_CONTENT") {
  return `<div style="text-align:center;margin:32px 0;">
<ins class="adsbygoogle" style="display:block;text-align:center;" data-ad-layout="in-article" data-ad-format="fluid" data-ad-client="ca-pub-YOUR_PUB_ID" data-ad-slot="YOUR_${slot}_SLOT_ID"></ins>
<script>(adsbygoogle=window.adsbygoogle||[]).push({});</script></div>`;
}

// ── FAQ Schema Markup ────────────────────────────────────────────
function buildFAQSchema(faqs) {
  if (!faqs||!faqs.length) return "";
  return `<script type="application/ld+json">{"@context":"https://schema.org","@type":"FAQPage","mainEntity":[${
    faqs.map(f=>`{"@type":"Question","name":${JSON.stringify(f.q)},"acceptedAnswer":{"@type":"Answer","text":${JSON.stringify(f.a)}}}`).join(",")
  }]}</script>`;
}

// ── Placeholder Blog Builder ─────────────────────────────────────
function buildPlaceholderBlog(topic, relatedTopics=[]) {
  const ilHTML  = buildInternalLinksHTML(topic, relatedTopics);
  const adHTML  = buildAdSenseHTML("MID_CONTENT");
  const ad2HTML = buildAdSenseHTML("BOTTOM_CONTENT");
  const content_html = `
<p><strong>${topic.title}</strong> – 2026 mein yah scheme lakho Bhartiyom ke liye ek bada mauka hai. Agar aap eligible hain to aaj hi apply karen aur government ka direct benefit payen.</p>
<h2>${topic.title} kya hai?</h2>
<p>Bharat Sarkar dwara shuru ki gayi yah yojana desh ke garib, madhyamvargiy aur kisan parivaron ko financial support dene ke liye banayi gayi hai. 2026 mein is scheme mein kai naye updates aaye hain jis se aur adhik log labh utha sakte hain. Yah yojana <a href="/scheme.html">sabhi sarkari yojanao</a> mein se ek mahatvapurna scheme hai.</p>
<h2>Mukhya Labh (Key Benefits)</h2>
<ul>
<li>Direct Bank Transfer (DBT) ke madhyam se labh</li>
<li>Nyuntam Documents ke sath Apply karo</li>
<li>Online aur Offline dono tarikse Application</li>
<li>SC/ST/OBC/EWS categories ke liye Extra Benefits</li>
<li>Mahilao aur Divyang ko prathamikta</li>
<li>Zero Processing Fee Government Scheme</li>
<li>Mobile App se Application Track kar sakte hain</li>
</ul>
<h2>Eligibility Criteria</h2>
<ul>
<li>Bharatiya nagrik hona anivarya</li>
<li>Aayu: 18 se 60 varsh (Senior Citizens ke liye alag niyam)</li>
<li>Valid Aadhaar Card aur Mobile Number linked hona chahiye</li>
<li>Bank Account (DBT ke liye mandatory)</li>
<li>Income Certificate (rajya ke anusar)</li>
<li>SC/ST/OBC ke liye Caste Certificate bhi required</li>
</ul>
${adHTML}
<h2>Step-by-Step Apply Process 2026</h2>
<ol>
<li><strong>Official Website:</strong> Government ki official portal par jayen</li>
<li><strong>Registration:</strong> Mobile Number aur Aadhaar se New Registration karo</li>
<li><strong>Form Fill:</strong> Personal Details, Bank Account, Income Details bharo</li>
<li><strong>Documents Upload:</strong> Aadhaar, Photo, Bank Passbook, Income Certificate upload karo</li>
<li><strong>Submit aur Track:</strong> Application submit karo aur Reference Number note karo</li>
<li><strong>Verification:</strong> 15-30 din mein Verification hogi</li>
<li><strong>Approval:</strong> Approved hone par SMS aur Email milega</li>
<li><strong>Benefit:</strong> Approved hone ke 7-15 din mein Bank mein Transfer</li>
</ol>
<h2>Jaruri Documents</h2>
<ul>
<li>Aadhaar Card (Mandatory)</li>
<li>Bank Passbook (First Page)</li>
<li>Passport Size Photo (Recent)</li>
<li>Income Certificate</li>
<li>Address Proof (Voter ID ya Ration Card)</li>
<li>Caste Certificate (if applicable)</li>
</ul>
<h2>Important Dates 2026</h2>
<ul>
<li>Application Start: January 2026 (Ongoing)</li>
<li>Last Date: December 31, 2026</li>
<li>Benefit Transfer: Quarterly/Monthly (scheme ke anusar)</li>
</ul>
${ilHTML}
<h2>Helpline aur Contact</h2>
<p>Toll-Free Helpline: 1800-180-1111 (Monday-Saturday, 9AM-6PM). Aap <a href="/scheme.html">sabhi sarkari yojanaen</a> dekh sakte hain ya <a href="/job.html">sarkari naukri</a> ki jankari le sakte hain. <a href="/blog/">Aur blogs padhen</a> zyada jankari ke liye.</p>
${ad2HTML}`;
  return {
    title: topic.title,
    metaDesc: `${topic.title.substring(0,100)} – 2026 complete guide. Eligibility, benefits, apply process Hindi mein. Official helpline aur documents list.`,
    content_html,
    faqs: [
      { q:`${topic.title} ke liye kaise apply karen?`, a:"Official government portal par jayen, Aadhaar aur bank details ke sath registration karo, form bharo aur documents upload karo. Application 15-30 din mein process hoti hai. Toll-free helpline 1800-180-1111 par call kar sakte hain." },
      { q:"Eligibility criteria kya hai?", a:"Bharatiya nagrik, aayu 18-60 varsh, valid Aadhaar card, bank account (DBT ke liye), aur income certificate required hai. SC/ST/OBC ke liye caste certificate bhi chahiye." },
      { q:"Documents kaun se chahiye?", a:"Aadhaar Card, Bank Passbook, Passport Size Photo, Income Certificate, Address Proof (Voter ID ya Ration Card), aur Caste Certificate (applicable ke liye) required hai." },
      { q:"Benefits kab aur kaise milte hain?", a:"Application approve hone ke 7-15 din ke andar Direct Bank Transfer (DBT) ke madhyam se aapke Aadhaar-linked bank account mein transfer hota hai." },
      { q:"Helpline number kya hai?", a:"Toll-free helpline: 1800-180-1111 (Monday-Saturday, 9AM-6PM). india.gov.in par bhi online complaint ya query darj kar sakte hain." },
    ],
  };
}

// ── AI Blog Generator ───────────────────────────────────────────
async function generateBlogWithAI(topic, apiKey, relatedTopics=[]) {
  const sys = `You are an expert SEO content writer for YojanaHub India's #1 government scheme portal. Write detailed SEO-optimized articles in Hindi-English Hinglish mix about government schemes loans insurance and jobs. MANDATORY: 1500-2000 words, h2 headings, benefits list with amounts, eligibility, step-by-step apply process, documents required, 5 FAQs. Include natural links to /scheme.html and /job.html. Return ONLY valid JSON: {"title":"SEO title","metaDesc":"155 char meta desc","content_html":"full HTML article","faqs":[{"q":"question","a":"answer"}]}`;
  const res = await axios.post("https://api.anthropic.com/v1/messages",{
    model:"claude-sonnet-4-20250514",max_tokens:4000,system:sys,
    messages:[{role:"user",content:`Write 1500-2000 word SEO blog: "${topic.title}". Keywords: ${topic.kws.join(", ")}. Category: ${topic.cat}. Include rupee amounts, eligibility, apply steps, 5 FAQs.`}],
  },{headers:{"x-api-key":apiKey,"anthropic-version":"2023-06-01","content-type":"application/json"},timeout:60000});
  const raw = res.data.content[0].text.replace(/```json\s*|```/g,"").trim();
  return JSON.parse(raw);
}

// ── Main Blog Generator ──────────────────────────────────────────
async function generateBlogs(apiKey, count=3) {
  const today = new Date().toISOString().split("T")[0];
  const existingSnap = await db.collection("blogs").where("publishDate","==",today).limit(10).get();
  const existingTitles = new Set(existingSnap.docs.map(d=>d.data().title));
  const allBlogsSnap = await db.collection("blogs").select("slug").limit(600).get();
  const existingSlugs = new Set(allBlogsSnap.docs.map(d=>d.data().slug));
  const pending = BLOG_TOPICS.filter(t=>!existingTitles.has(t.title)&&!existingSlugs.has(slugify(t.title)));
  if (!pending.length) { console.log("All blog topics published."); return 0; }
  const picked = pending.sort(()=>Math.random()-0.5).slice(0,count);
  let generated = 0;
  for (const topic of picked) {
    const slug = slugify(topic.title);
    const relatedTopics = BLOG_TOPICS.filter(t=>t.cat===topic.cat&&t.title!==topic.title).sort(()=>Math.random()-0.5).slice(0,5);
    try {
      let blog;
      if (apiKey) {
        blog = await generateBlogWithAI(topic, apiKey, relatedTopics);
        const ilHTML = buildInternalLinksHTML(topic, relatedTopics);
        const adHTML = buildAdSenseHTML("MID_CONTENT");
        if (!blog.content_html.includes("adsbygoogle")) blog.content_html = blog.content_html.replace(/<\/h2>/,"</h2>"+adHTML,1);
        if (!blog.content_html.includes("Related Guides")) blog.content_html += ilHTML;
        console.log("AI blog: "+topic.title);
      } else {
        blog = buildPlaceholderBlog(topic, relatedTopics);
        console.log("Placeholder blog: "+topic.title);
      }
      const faqSchema = buildFAQSchema(blog.faqs||[]);
      await db.collection("blogs").add({
        title:blog.title||topic.title, slug,
        metaDesc:blog.metaDesc||topic.title,
        content_html:blog.content_html||"",
        faqs:blog.faqs||[], faqSchema,
        keywords:topic.kws,
        publishDate:today,
        createdAt:admin.firestore.FieldValue.serverTimestamp(),
        views:0, clicks:0,
        isAutoGenerated:true, status:"published",
        category:topic.cat||detectCategory(topic.kws),
        internalLinks:relatedTopics.slice(0,3).map(t=>({title:t.title,slug:slugify(t.title)})),
      });
      generated++;
    } catch(err) {
      console.error("Blog gen error:", err.message);
      const blog = buildPlaceholderBlog(topic, relatedTopics);
      const faqSchema = buildFAQSchema(blog.faqs||[]);
      await db.collection("blogs").add({
        title:blog.title||topic.title, slug,
        metaDesc:blog.metaDesc||topic.title,
        content_html:blog.content_html||"",
        faqs:blog.faqs||[], faqSchema,
        keywords:topic.kws, publishDate:today,
        createdAt:admin.firestore.FieldValue.serverTimestamp(),
        views:0, clicks:0, isAutoGenerated:true, status:"published",
        category:topic.cat||detectCategory(topic.kws),
        internalLinks:relatedTopics.slice(0,3).map(t=>({title:t.title,slug:slugify(t.title)})),
      });
      generated++;
    }
  }
  console.log("Generated "+generated+" blogs");
  return generated;
}

function detectCategory(keywords) {
  const kw=(keywords||[]).join(" ").toLowerCase();
  if(kw.includes("loan")||kw.includes("cibil"))return "Loan";
  if(kw.includes("insurance")||kw.includes("bima"))return "Insurance";
  if(kw.includes("job")||kw.includes("naukri")||kw.includes("exam"))return "Jobs";
  if(kw.includes("kisan")||kw.includes("farmer")||kw.includes("krishi"))return "Farmer";
  if(kw.includes("scholarship")||kw.includes("education"))return "Education";
  if(kw.includes("housing")||kw.includes("awas"))return "Housing";
  if(kw.includes("women")||kw.includes("mahila")||kw.includes("beti"))return "Women";
  if(kw.includes("health")||kw.includes("ayushman"))return "Health";
  if(kw.includes("subsidy")||kw.includes("solar")||kw.includes("lpg"))return "Subsidy";
  if(kw.includes("business")||kw.includes("msme")||kw.includes("startup"))return "Business";
  if(kw.includes("finance")||kw.includes("investment")||kw.includes("ppf"))return "Finance";
  return "Government Scheme";
}

module.exports = { generateBlogs, BLOG_TOPICS, slugify, buildInternalLinksHTML, buildAdSenseHTML, buildFAQSchema, buildPlaceholderBlog };
