// ================================================================
// /functions/scraper.js — YojanaHub Auto Scraper System
// Exports: scrapeSchemes(), scrapeJobs()
// Runs via CRON every 6 hours from index.js
// ================================================================

"use strict";

const admin = require("firebase-admin");
const db    = admin.firestore();

// ── Expanded Schemes Data (150+ entries seeded progressively) ──
const SCHEMES_SEED = [
  // ── LOAN SCHEMES (High CPC) ──
  { title_hi:"PM मुद्रा लोन योजना 2026",title_en:"PM Mudra Loan Yojana 2026",slug:"pm-mudra-loan-yojana-2026",category:"Loan",state:"All India",benefit:"Loan up to ₹10 lakh for small businesses",eligibility:"Non-corporate, non-farm small/micro enterprises",applyLink:"https://mudra.org.in",keywords:["mudra loan","business loan","govt loan india","loan schemes india"],views:9800,isTrending:true },
  { title_hi:"StandUp India Loan",title_en:"StandUp India Loan Scheme",slug:"standup-india-loan-scheme",category:"Loan",state:"All India",benefit:"₹10 lakh to ₹1 crore for SC/ST/Women entrepreneurs",eligibility:"SC, ST or Women first-time entrepreneur",applyLink:"https://standupmitra.in",keywords:["standup india","sc st loan","women entrepreneur loan","govt subsidy business"],views:6200,isTrending:true },
  { title_hi:"PM SVANidhi Loan – Street Vendor",title_en:"PM SVANidhi Street Vendor Loan",slug:"pm-svanidhi-street-vendor-loan",category:"Loan",state:"All India",benefit:"₹10,000 to ₹50,000 collateral-free loan",eligibility:"Urban street vendors with ULB certificate",applyLink:"https://pmsvanidhi.mohua.gov.in",keywords:["svanidhi loan","street vendor loan","hawker loan india"],views:5100,isTrending:false },
  { title_hi:"SBI E-Mudra Loan 2026",title_en:"SBI E-Mudra Instant Loan 2026",slug:"sbi-emudra-instant-loan-2026",category:"Loan",state:"All India",benefit:"Instant ₹1 lakh via YONO app – 59 minutes approval",eligibility:"SBI account holder with micro/small business",applyLink:"https://sbi.co.in",keywords:["sbi mudra loan","emudra loan","instant business loan"],views:7800,isTrending:true },
  { title_hi:"PMEGP Loan 2026 – ₹50 लाख",title_en:"PMEGP Loan 2026 – Up to ₹50 Lakh",slug:"pmegp-loan-2026",category:"Loan",state:"All India",benefit:"25-35% subsidy on ₹50 lakh manufacturing loan",eligibility:"Individual above 18 years, 8th pass for >10L loan",applyLink:"https://kviconline.gov.in",keywords:["pmegp loan 2026","manufacturing loan india","govt subsidy business"],views:4800,isTrending:false },
  { title_hi:"NABARD Kisan Loan 2026",title_en:"NABARD Agricultural Loan 2026",slug:"nabard-agricultural-loan-2026",category:"Loan",state:"All India",benefit:"Low interest agricultural loans via cooperative banks",eligibility:"Farmers, FPOs, and rural entrepreneurs",applyLink:"https://nabard.org",keywords:["nabard loan","kisan loan","agricultural loan india","किसान लोन योजना"],views:3900,isTrending:false },

  // ── INSURANCE SCHEMES (High CPC) ──
  { title_hi:"PM Jeevan Jyoti Bima Yojana 2026",title_en:"PM Jeevan Jyoti Bima Yojana 2026",slug:"pmjjby-2026",category:"Insurance",state:"All India",benefit:"₹2 lakh life insurance at just ₹436/year",eligibility:"18-50 years, savings bank account holder",applyLink:"https://jansuraksha.gov.in",keywords:["pmjjby","jeevan jyoti bima","life insurance scheme","insurance schemes india"],views:8100,isTrending:true },
  { title_hi:"PM Suraksha Bima Yojana 2026",title_en:"PM Suraksha Bima Yojana 2026",slug:"pmsby-2026",category:"Insurance",state:"All India",benefit:"₹2 lakh accidental insurance at ₹20/year",eligibility:"18-70 years, bank account holder",applyLink:"https://jansuraksha.gov.in",keywords:["pmsby","suraksha bima yojana","accident insurance","insurance schemes india"],views:7600,isTrending:true },
  { title_hi:"PM Fasal Bima Yojana 2026",title_en:"PM Fasal Bima Yojana 2026",slug:"pmfby-crop-insurance-2026",category:"Insurance",state:"All India",benefit:"Crop insurance – premium from 1.5% to 5%",eligibility:"All farmers including tenant and sharecroppers",applyLink:"https://pmfby.gov.in",keywords:["pmfby","crop insurance","kisan bima","insurance schemes india","किसान लोन योजना"],views:6800,isTrending:true },
  { title_hi:"Atal Pension Yojana 2026",title_en:"Atal Pension Yojana 2026",slug:"atal-pension-yojana-2026",category:"Insurance",state:"All India",benefit:"₹1,000 – ₹5,000/month guaranteed pension",eligibility:"18-40 years unorganized sector workers",applyLink:"https://npscra.nsdl.co.in",keywords:["atal pension yojana","apy 2026","pension scheme india","insurance schemes india"],views:9200,isTrending:true },

  // ── FARMER SCHEMES (High CPC: किसान लोन योजना) ──
  { title_hi:"PM किसान सम्मान निधि 2026",title_en:"PM Kisan Samman Nidhi 2026",slug:"pm-kisan-samman-nidhi-2026",category:"Farmer",state:"All India",benefit:"₹6,000/year in 3 installments",eligibility:"Small & marginal farmers with less than 2 hectare land",applyLink:"https://pmkisan.gov.in",keywords:["pm kisan","kisan yojana","farmer scheme","किसान लोन योजना"],views:15000,isTrending:true },
  { title_hi:"किसान क्रेडिट कार्ड 2026",title_en:"Kisan Credit Card 2026",slug:"kisan-credit-card-2026",category:"Farmer",state:"All India",benefit:"Loan up to ₹3 lakh at 4% interest rate",eligibility:"All farmers including tenant farmers",applyLink:"https://nabard.org",keywords:["kisan credit card","kcc","farmer loan","किसान लोन योजना"],views:6900,isTrending:true },
  { title_hi:"PM Kisan Maan Dhan Yojana",title_en:"PM Kisan Maan Dhan Yojana 2026",slug:"pm-kisan-maandhan-2026",category:"Farmer",state:"All India",benefit:"₹3,000/month pension for farmers at 60",eligibility:"Small marginal farmers 18-40 years",applyLink:"https://pmkmy.gov.in",keywords:["pm kisan maandhan","farmer pension","kisan yojana 2026","किसान लोन योजना"],views:4200,isTrending:false },
  { title_hi:"Soil Health Card Scheme 2026",title_en:"Soil Health Card Scheme 2026",slug:"soil-health-card-2026",category:"Farmer",state:"All India",benefit:"Free soil testing + fertilizer recommendation card",eligibility:"All farmers in India",applyLink:"https://soilhealth.dac.gov.in",keywords:["soil health card","kisan scheme 2026","farm subsidy india"],views:2800,isTrending:false },

  // ── HOUSING SCHEMES ──
  { title_hi:"PM आवास योजना – ग्रामीण 2026",title_en:"PM Awas Yojana Gramin 2026",slug:"pm-awas-yojana-gramin-2026",category:"Housing",state:"All India",benefit:"₹1.2–1.5 lakh housing subsidy",eligibility:"Homeless families, kutcha house owners in rural areas",applyLink:"https://pmayg.nic.in",keywords:["pm awas yojana","housing scheme","free house govt"],views:8500,isTrending:false },
  { title_hi:"PM आवास योजना – शहरी 2026",title_en:"PM Awas Yojana Urban 2026",slug:"pm-awas-yojana-urban-2026",category:"Housing",state:"All India",benefit:"₹1 lakh to ₹2.67 lakh CLSS subsidy",eligibility:"EWS/LIG/MIG families – first-time buyers",applyLink:"https://pmaymis.gov.in",keywords:["pm awas yojana urban","housing loan subsidy","pmay clss"],views:7200,isTrending:true },
  { title_hi:"PM SVAMITVA Yojana 2026",title_en:"PM SVAMITVA Property Card 2026",slug:"pm-svamitva-2026",category:"Housing",state:"All India",benefit:"Rural property card for bank loan eligibility",eligibility:"Rural households in gram sabha inhabited areas",applyLink:"https://svamitva.nic.in",keywords:["svamitva yojana","property card","village land rights","govt subsidy business"],views:3600,isTrending:false },

  // ── WOMEN SCHEMES ──
  { title_hi:"Sukanya Samriddhi Yojana 2026",title_en:"Sukanya Samriddhi Yojana 2026",slug:"sukanya-samriddhi-yojana-2026",category:"Women",state:"All India",benefit:"8.2% interest, tax-free savings for girl child",eligibility:"Girl child below 10 years",applyLink:"https://nsiindia.gov.in",keywords:["sukanya samriddhi","girl child scheme","women scheme india"],views:7200,isTrending:false },
  { title_hi:"PM Ujjwala Yojana 2.0",title_en:"PM Ujjwala Yojana 2.0",slug:"pm-ujjwala-yojana-2026",category:"Women",state:"All India",benefit:"Free LPG connection + first cylinder free",eligibility:"BPL/SECC women who don't have LPG",applyLink:"https://pmuy.gov.in",keywords:["ujjwala yojana","free lpg","women scheme india"],views:6300,isTrending:false },
  { title_hi:"Beti Bachao Beti Padhao 2026",title_en:"Beti Bachao Beti Padhao 2026",slug:"beti-bachao-beti-padhao-2026",category:"Women",state:"All India",benefit:"Cash incentives + scholarships for girl child",eligibility:"All families with girl child up to 18 years",applyLink:"https://wcd.nic.in",keywords:["beti bachao","girl child scheme","women scheme india"],views:5100,isTrending:false },

  // ── HEALTH SCHEMES ──
  { title_hi:"आयुष्मान भारत – PM-JAY 2026",title_en:"Ayushman Bharat PM-JAY 2026",slug:"ayushman-bharat-pmjay-2026",category:"Health",state:"All India",benefit:"₹5 lakh/year health insurance per family",eligibility:"SECC database beneficiaries, BPL families",applyLink:"https://pmjay.gov.in",keywords:["ayushman bharat","health scheme","pmjay","insurance schemes india"],views:12000,isTrending:true },
  { title_hi:"Janani Suraksha Yojana 2026",title_en:"Janani Suraksha Yojana 2026",slug:"janani-suraksha-yojana-2026",category:"Health",state:"All India",benefit:"₹1,400 cash for institutional delivery",eligibility:"Pregnant women from low-income families",applyLink:"https://nhm.gov.in",keywords:["janani suraksha","maternity scheme","maternal health india"],views:4100,isTrending:false },

  // ── EDUCATION/STUDENT ──
  { title_hi:"राष्ट्रीय छात्रवृत्ति पोर्टल 2026",title_en:"National Scholarship Portal 2026",slug:"national-scholarship-portal-2026",category:"Student",state:"All India",benefit:"Scholarship up to ₹50,000/year for students",eligibility:"Students from minority, SC/ST, OBC with 50%+ marks",applyLink:"https://scholarships.gov.in",keywords:["scholarship","student scheme","education scheme"],views:5500,isTrending:false },
  { title_hi:"Central Sector Scholarship 2026",title_en:"Central Sector Scholarship 2026",slug:"central-sector-scholarship-2026",category:"Student",state:"All India",benefit:"₹10,000-₹20,000/year for college students",eligibility:"Top 80th percentile in Class 12 board exams",applyLink:"https://scholarships.gov.in",keywords:["central sector scholarship","college scholarship","merit scholarship india"],views:4300,isTrending:false },

  // ── ENERGY ──
  { title_hi:"PM सूर्य घर – मुफ्त बिजली 2026",title_en:"PM Surya Ghar Free Electricity 2026",slug:"pm-surya-ghar-muft-bijli-2026",category:"Energy",state:"All India",benefit:"Free electricity up to 300 units/month via solar",eligibility:"Residential households with own rooftop",applyLink:"https://pmsuryaghar.gov.in",keywords:["solar scheme","free electricity","surya ghar","govt subsidy"],views:6100,isTrending:true },

  // ── BUSINESS/ENTERPRISE ──
  { title_hi:"PM Vishwakarma Yojana 2026",title_en:"PM Vishwakarma Yojana 2026",slug:"pm-vishwakarma-yojana-2026",category:"Business",state:"All India",benefit:"₹3 lakh loan + free training for 18 traditional trades",eligibility:"Traditional artisans and craftspeople",applyLink:"https://pmvishwakarma.gov.in",keywords:["pm vishwakarma","artisan loan","craftsman scheme","govt subsidy business"],views:5800,isTrending:true },
  { title_hi:"PMEGP – Manufacturing Subsidy",title_en:"PMEGP Manufacturing Subsidy 2026",slug:"pmegp-manufacturing-subsidy-2026",category:"Business",state:"All India",benefit:"25-35% subsidy for manufacturing enterprises",eligibility:"18+ individuals, 8th pass for loans above ₹10L",applyLink:"https://kviconline.gov.in",keywords:["pmegp scheme","manufacturing subsidy","govt subsidy business"],views:4200,isTrending:false },
];

// ── Expanded Jobs Data ───────────────────────────────────────────
const JOBS_SEED = [
  { title:"SSC CGL 2026 Notification",organization:"Staff Selection Commission",posts:17727,lastDate:"2026-06-15",category:"Central Govt",level:"Graduate",officialLink:"https://ssc.nic.in",salary:"₹25,500 – ₹1,51,100",state:"All India",slug:"ssc-cgl-2026",keywords:["ssc cgl","central govt job","sarkari naukri graduate"],views:22000,isTrending:true },
  { title:"SSC GD Constable 2026 – 45,000 Posts",organization:"Staff Selection Commission",posts:45000,lastDate:"2026-07-01",category:"Central Govt",level:"10th Pass",officialLink:"https://ssc.nic.in",salary:"₹21,700 – ₹69,100",state:"All India",slug:"ssc-gd-constable-2026",keywords:["ssc gd","constable job","10th pass govt job"],views:18500,isTrending:true },
  { title:"Railway NTPC 2026 – 11,558 Posts",organization:"Railway Recruitment Board",posts:11558,lastDate:"2026-05-30",category:"Railway",level:"12th Pass",officialLink:"https://indianrailways.gov.in",salary:"₹19,900 – ₹35,400",state:"All India",slug:"rrb-ntpc-2026",keywords:["railway job","rrb ntpc","sarkari naukri 12th pass"],views:19000,isTrending:true },
  { title:"RRB Group D 2026 – 32,000 Vacancies",organization:"Railway Recruitment Board",posts:32000,lastDate:"2026-06-15",category:"Railway",level:"10th Pass",officialLink:"https://rrbapply.gov.in",salary:"₹18,000 – ₹56,900",state:"All India",slug:"rrb-group-d-2026",keywords:["rrb group d","railway group d","10th pass railway job"],views:16800,isTrending:true },
  { title:"IBPS PO Recruitment 2026",organization:"Institute of Banking Personnel Selection",posts:3517,lastDate:"2026-07-10",category:"Banking",level:"Graduate",officialLink:"https://ibps.in",salary:"₹41,960 – ₹51,490",state:"All India",slug:"ibps-po-2026",keywords:["ibps po","bank job","banking exam 2026"],views:14000,isTrending:true },
  { title:"IBPS Clerk 2026 – 5000+ Posts",organization:"Institute of Banking Personnel Selection",posts:5000,lastDate:"2026-07-25",category:"Banking",level:"Graduate",officialLink:"https://ibps.in",salary:"₹11,765 – ₹42,020",state:"All India",slug:"ibps-clerk-2026",keywords:["ibps clerk","bank clerk job","banking jobs 2026"],views:11200,isTrending:true },
  { title:"UP Police Constable 2026",organization:"Uttar Pradesh Police Recruitment Board",posts:60244,lastDate:"2026-05-20",category:"State Police",level:"10th / 12th Pass",officialLink:"https://uppbpb.gov.in",salary:"₹21,700 – ₹69,100",state:"Uttar Pradesh",slug:"up-police-constable-2026",keywords:["up police","police constable","state govt job up"],views:11000,isTrending:true },
  { title:"UPSC Civil Services 2026",organization:"Union Public Service Commission",posts:1056,lastDate:"2026-06-01",category:"IAS/IPS",level:"Graduate",officialLink:"https://upsc.gov.in",salary:"₹56,100 – ₹2,50,000",state:"All India",slug:"upsc-civil-services-2026",keywords:["upsc 2026","ias exam","civil services"],views:18000,isTrending:true },
  { title:"Agniveer Army 2026",organization:"Indian Army",posts:50000,lastDate:"2026-08-01",category:"Defence",level:"10th/12th Pass",officialLink:"https://joinindianarmy.nic.in",salary:"₹30,000 – ₹40,000",state:"All India",slug:"agniveer-army-2026",keywords:["agniveer","army job","defence job 2026"],views:15600,isTrending:true },
  { title:"MPSC State Services 2026",organization:"Maharashtra Public Service Commission",posts:800,lastDate:"2026-05-15",category:"State Govt",level:"Graduate",officialLink:"https://mpsc.gov.in",salary:"₹41,800 – ₹1,32,300",state:"Maharashtra",slug:"mpsc-state-services-2026",keywords:["mpsc 2026","maharashtra govt job","state civil services"],views:8900,isTrending:false },
  { title:"NHM Health Worker Recruitment 2026",organization:"National Health Mission",posts:12000,lastDate:"2026-05-30",category:"Health",level:"12th Pass / ANM",officialLink:"https://nhm.gov.in",salary:"₹12,000 – ₹25,000",state:"Multiple States",slug:"nhm-health-worker-2026",keywords:["nhm recruitment","health worker job","medical job 2026"],views:7400,isTrending:false },
  { title:"DRDO Scientist Recruitment 2026",organization:"Defence Research & Development Organisation",posts:1800,lastDate:"2026-07-20",category:"Defence R&D",level:"Graduate/Postgraduate",officialLink:"https://drdo.gov.in",salary:"₹56,100 – ₹2,50,000",state:"All India",slug:"drdo-scientist-2026",keywords:["drdo recruitment","scientist job india","defence research job"],views:9200,isTrending:false },
  { title:"Income Tax Inspector 2026 – SSC CGL",organization:"Income Tax Department / SSC",posts:2000,lastDate:"2026-06-15",category:"Central Govt",level:"Graduate",officialLink:"https://ssc.nic.in",salary:"₹44,900 – ₹1,42,400",state:"All India",slug:"income-tax-inspector-2026",keywords:["income tax inspector","ssc cgl it inspector","central govt graduate job"],views:8700,isTrending:false },
  { title:"Bihar Police SI Recruitment 2026",organization:"Bihar Police Subordinate Services Commission",posts:2200,lastDate:"2026-06-10",category:"State Police",level:"Graduate",officialLink:"https://bpssc.bih.nic.in",salary:"₹35,800 – ₹1,13,500",state:"Bihar",slug:"bihar-police-si-2026",keywords:["bihar police si","sub inspector bihar","state police job"],views:6100,isTrending:false },
  { title:"MP Police Constable 2026",organization:"Madhya Pradesh Police",posts:7500,lastDate:"2026-05-25",category:"State Police",level:"12th Pass",officialLink:"https://peb.mp.gov.in",salary:"₹19,500 – ₹62,000",state:"Madhya Pradesh",slug:"mp-police-constable-2026",keywords:["mp police","constable mp","state police job 2026"],views:5400,isTrending:false },
];

// ── Write to Firestore (deduplicated by slug) ────────────────────
async function upsertDocs(collectionName, items) {
  let added = 0, skipped = 0;
  for (const item of items) {
    try {
      const existing = await db.collection(collectionName)
        .where("slug", "==", item.slug).limit(1).get();
      if (!existing.empty) { skipped++; continue; }
      await db.collection(collectionName).add({
        ...item,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
      added++;
    } catch (err) {
      console.error(`Error adding ${item.slug}:`, err.message);
    }
  }
  return { added, skipped };
}

async function scrapeSchemes() {
  const result = await upsertDocs("schemes", SCHEMES_SEED);
  console.log(`✅ Schemes: ${result.added} added, ${result.skipped} skipped`);
  return result;
}

async function scrapeJobs() {
  const result = await upsertDocs("jobs", JOBS_SEED);
  console.log(`✅ Jobs: ${result.added} added, ${result.skipped} skipped`);
  return result;
}

module.exports = { scrapeSchemes, scrapeJobs };

// ── Regional/State-specific Schemes ──────────────────────────────
const STATE_SCHEMES_SEED = [
  // Maharashtra
  { title_hi:"Ladki Bahin Yojana – MH",title_en:"Mukhyamantri Ladki Bahin Yojana Maharashtra",slug:"ladki-bahin-yojana-maharashtra",category:"Women",state:"Maharashtra",benefit:"₹1,500/month cash to women 21-65 years",eligibility:"Maharashtra women, family income < ₹2.5 lakh",applyLink:"https://ladakibahin.maharashtra.gov.in",keywords:["ladki bahin yojana","maharashtra women scheme","sarkari yojana maharashtra"],views:12000,isTrending:true },
  { title_hi:"Annasaheb Patil Loan Yojana",title_en:"Annasaheb Patil Economic Development Corporation Loan",slug:"annasaheb-patil-loan-maharashtra",category:"Loan",state:"Maharashtra",benefit:"₹10 lakh loan for Maratha community at low interest",eligibility:"Maratha community, income < ₹8 lakh",applyLink:"https://mahaswayam.gov.in",keywords:["annasaheb patil loan","maratha loan scheme","maharashtra loan"],views:7800,isTrending:true },
  // UP
  { title_hi:"UP Kanya Sumangala Yojana",title_en:"Kanya Sumangala Yojana UP",slug:"kanya-sumangala-yojana-up",category:"Women",state:"Uttar Pradesh",benefit:"₹25,000 in 6 installments for girl child",eligibility:"UP family, family income < ₹3 lakh, girl child",applyLink:"https://mksy.up.gov.in",keywords:["kanya sumangala yojana","up girl scheme","uttar pradesh women scheme"],views:9500,isTrending:true },
  { title_hi:"UP Free Laptop Yojana 2026",title_en:"UP Free Laptop Distribution Scheme 2026",slug:"up-free-laptop-yojana-2026",category:"Education",state:"Uttar Pradesh",benefit:"Free laptop for 10th/12th pass students",eligibility:"UP students with 65%+ marks in board exams",applyLink:"https://upcmo.up.nic.in",keywords:["up free laptop 2026","uttar pradesh laptop scheme","student scheme up"],views:8900,isTrending:true },
  // Rajasthan
  { title_hi:"Rajasthan Chiranjeevi Yojana",title_en:"Mukhyamantri Chiranjeevi Swasthya Bima Yojana",slug:"chiranjeevi-yojana-rajasthan",category:"Health",state:"Rajasthan",benefit:"₹25 lakh health insurance per family",eligibility:"Rajasthan BPL/SECC/Jan Aadhaar family",applyLink:"https://chiranjeevi.rajasthan.gov.in",keywords:["chiranjeevi yojana","rajasthan health scheme","free insurance rajasthan"],views:11000,isTrending:true },
  // Gujarat  
  { title_hi:"Gujarat Kisan Sahayta Yojana",title_en:"Gujarat Kisan Sahayta Yojana",slug:"gujarat-kisan-sahayta-2026",category:"Farmer",state:"Gujarat",benefit:"₹4,000/acre subsidy for drought/flood affected farmers",eligibility:"Gujarat farmers affected by natural disaster",applyLink:"https://digitalgujarat.gov.in",keywords:["gujarat kisan sahayta","gujarat farmer scheme","kisan yojana gujarat"],views:5200,isTrending:false },
  // Bihar
  { title_hi:"Bihar Mukhyamantri Kanya Vivah Yojana",title_en:"Bihar Kanya Vivah Yojana",slug:"bihar-kanya-vivah-yojana-2026",category:"Women",state:"Bihar",benefit:"₹5,000 cash grant at daughter's marriage",eligibility:"Bihar BPL family, daughter age 18+",applyLink:"https://serviceonline.bihar.gov.in",keywords:["bihar kanya vivah yojana","bihar marriage scheme","women scheme bihar"],views:6800,isTrending:false },
  // Tamil Nadu
  { title_hi:"TN Kalaignar Magalir Urimai Thittam",title_en:"Kalaignar Magalir Urimai Thittam – Tamil Nadu",slug:"tn-magalir-urimai-2026",category:"Women",state:"Tamil Nadu",benefit:"₹1,000/month to women head of household",eligibility:"Tamil Nadu women 21+ who are family heads",applyLink:"https://murasoli.tn.gov.in",keywords:["magalir urimai thittam","tamil nadu women scheme","tn govt scheme 2026"],views:8200,isTrending:true },
];

async function scrapeStateSchemes() {
  const result = await upsertDocs("schemes", STATE_SCHEMES_SEED);
  console.log(`✅ State Schemes: ${result.added} added, ${result.skipped} skipped`);
  return result;
}

module.exports = { scrapeSchemes, scrapeJobs, scrapeStateSchemes };
