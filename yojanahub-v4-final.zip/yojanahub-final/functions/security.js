// ================================================================
// /functions/security.js — YojanaHub Security Layer v2.0
// Rate limiting | DDoS protection | Input sanitization | WAF rules
// ================================================================
"use strict";

const admin = require("firebase-admin");
const db = admin.firestore();

// ── In-Memory Rate Limiter (per Cloud Function instance) ─────────
const rateLimitStore = new Map();
const RATE_LIMITS = {
  search:    { windowMs: 60000, max: 30  }, // 30 req/min per IP
  trending:  { windowMs: 60000, max: 60  }, // 60 req/min per IP
  api:       { windowMs: 60000, max: 20  }, // 20 req/min per IP
  default:   { windowMs: 60000, max: 100 }, // 100 req/min per IP
};

function getClientIP(req) {
  return (
    req.headers["x-forwarded-for"]?.split(",")[0]?.trim() ||
    req.headers["x-real-ip"] ||
    req.connection?.remoteAddress ||
    "unknown"
  );
}

function checkRateLimit(ip, type = "default") {
  const limit = RATE_LIMITS[type] || RATE_LIMITS.default;
  const key = `${type}:${ip}`;
  const now = Date.now();

  if (!rateLimitStore.has(key)) {
    rateLimitStore.set(key, { count: 1, resetAt: now + limit.windowMs });
    return { allowed: true, remaining: limit.max - 1 };
  }

  const entry = rateLimitStore.get(key);
  if (now > entry.resetAt) {
    rateLimitStore.set(key, { count: 1, resetAt: now + limit.windowMs });
    return { allowed: true, remaining: limit.max - 1 };
  }

  entry.count++;
  if (entry.count > limit.max) {
    return { allowed: false, remaining: 0, retryAfter: Math.ceil((entry.resetAt - now) / 1000) };
  }
  return { allowed: true, remaining: limit.max - entry.count };
}

// Clean up old entries every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, val] of rateLimitStore.entries()) {
    if (now > val.resetAt) rateLimitStore.delete(key);
  }
}, 300000);

// ── Blocklist — Persistent (Firestore) ───────────────────────────
const blockedIPCache = new Set();
let blockedIPsCacheTime = 0;

async function isIPBlocked(ip) {
  const now = Date.now();
  // Refresh cache every 10 minutes
  if (now - blockedIPsCacheTime > 600000) {
    try {
      const snap = await db.collection("security").doc("blocked_ips").get();
      if (snap.exists) {
        const ips = snap.data().ips || [];
        blockedIPCache.clear();
        ips.forEach(i => blockedIPCache.add(i));
      }
      blockedIPsCacheTime = now;
    } catch (_) {}
  }
  return blockedIPCache.has(ip);
}

async function blockIP(ip, reason = "automated") {
  blockedIPCache.add(ip);
  try {
    await db.collection("security").doc("blocked_ips").set({
      ips: admin.firestore.FieldValue.arrayUnion(ip),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });
    await db.collection("security_logs").add({
      type: "ip_blocked", ip, reason,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  } catch (_) {}
}

// ── Input Sanitization ───────────────────────────────────────────
function sanitizeString(input, maxLen = 200) {
  if (typeof input !== "string") return "";
  return input
    .substring(0, maxLen)
    .replace(/[<>'"]/g, "")          // Strip XSS chars
    .replace(/javascript:/gi, "")    // No JS protocol
    .replace(/on\w+\s*=/gi, "")      // No event handlers
    .replace(/data:/gi, "")          // No data URIs
    .replace(/vbscript:/gi, "")      // No VBScript
    .trim();
}

function sanitizeSearchQuery(q, maxLen = 100) {
  if (typeof q !== "string") return "";
  return q
    .substring(0, maxLen)
    .replace(/[^a-zA-Z0-9\u0900-\u097F\s\-.,]/g, "") // Allow Hindi + basic chars
    .trim();
}

// ── SQL/NoSQL Injection Detector ─────────────────────────────────
const INJECTION_PATTERNS = [
  /(\$where|\$regex|\$ne|\$gt|\$lt|\$in|\$or|\$and)/i,  // NoSQL injection
  /(union\s+select|drop\s+table|insert\s+into|delete\s+from)/i, // SQL injection
  /(eval\(|exec\(|system\(|passthru\()/i,                 // Code injection
  /(\.\.\/)|(\.\.\\)/,                                     // Path traversal
  /<script[\s\S]*?>/i,                                     // XSS
];

function containsInjection(value) {
  if (typeof value !== "string") return false;
  return INJECTION_PATTERNS.some(p => p.test(value));
}

function validateRequest(req) {
  const errors = [];
  // Check all query params
  for (const [key, val] of Object.entries(req.query || {})) {
    if (containsInjection(String(val))) {
      errors.push(`Suspicious parameter: ${key}`);
    }
  }
  // Check body params
  if (req.body && typeof req.body === "object") {
    for (const [key, val] of Object.entries(req.body)) {
      if (typeof val === "string" && containsInjection(val)) {
        errors.push(`Suspicious body field: ${key}`);
      }
    }
  }
  // Check User-Agent (basic bot detection)
  const ua = req.headers["user-agent"] || "";
  if (!ua || ua.length < 5) errors.push("Missing/suspicious user agent");
  return errors;
}

// ── Security Headers Middleware ───────────────────────────────────
function applySecurityHeaders(res) {
  res.set({
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "SAMEORIGIN",
    "X-XSS-Protection": "1; mode=block",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=(), payment=()",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
    "Content-Security-Policy": [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' https://pagead2.googlesyndication.com https://www.googletagmanager.com https://www.gstatic.com https://www.google-analytics.com https://firebase.googleapis.com https://cdnjs.cloudflare.com",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: https: blob:",
      "connect-src 'self' https://*.firebaseio.com https://*.googleapis.com https://pagead2.googlesyndication.com",
      "frame-src https://googleads.g.doubleclick.net https://tpc.googlesyndication.com",
      "object-src 'none'",
    ].join("; "),
  });
}

// ── Main Security Middleware ──────────────────────────────────────
async function securityMiddleware(req, res, type = "default") {
  applySecurityHeaders(res);
  const ip = getClientIP(req);

  // 1. Check IP blocklist
  if (await isIPBlocked(ip)) {
    await db.collection("security_logs").add({
      type: "blocked_request", ip, path: req.path || "/",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    res.status(403).json({ error: "Access denied" });
    return false;
  }

  // 2. Rate limiting
  const rateResult = checkRateLimit(ip, type);
  res.set("X-RateLimit-Remaining", String(rateResult.remaining));
  if (!rateResult.allowed) {
    // Auto-block repeat offenders (> 3 rate limit violations stored in memory)
    const violationKey = `violations:${ip}`;
    const violations = (rateLimitStore.get(violationKey)?.count || 0) + 1;
    rateLimitStore.set(violationKey, { count: violations, resetAt: Date.now() + 3600000 });
    if (violations >= 10) await blockIP(ip, "repeated_rate_limit_violations");

    res.set("Retry-After", String(rateResult.retryAfter || 60));
    res.status(429).json({ error: "Too many requests. Please slow down.", retryAfter: rateResult.retryAfter });
    return false;
  }

  // 3. Request validation (injection detection)
  const validationErrors = validateRequest(req);
  if (validationErrors.length > 0) {
    await db.collection("security_logs").add({
      type: "injection_attempt", ip, errors: validationErrors,
      path: req.path || "/", ua: req.headers["user-agent"] || "",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    }).catch(() => {});
    res.status(400).json({ error: "Invalid request" });
    return false;
  }

  return true; // All checks passed
}

// ── CORS Validator ────────────────────────────────────────────────
const ALLOWED_ORIGINS = [
  "https://yojanahub.in",
  "https://www.yojanahub.in",
  "http://localhost:5000",
  "http://localhost:3000",
];

function validateCORS(req, res) {
  const origin = req.headers.origin || "";
  if (ALLOWED_ORIGINS.includes(origin)) {
    res.set("Access-Control-Allow-Origin", origin);
    res.set("Vary", "Origin");
  } else if (!origin) {
    // Direct API call without origin (server-to-server) — allow
    res.set("Access-Control-Allow-Origin", "https://yojanahub.in");
  } else {
    // Unknown origin — still allow but log
    res.set("Access-Control-Allow-Origin", "https://yojanahub.in");
  }
  res.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.set("Access-Control-Max-Age", "86400");
}

// ── Security Status HTTP Handler ──────────────────────────────────
async function handleSecurityStatus(req, res) {
  const secret = req.query.key;
  // Only accessible with secret key
  if (!secret || secret.length < 8) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  const [blockedSnap, logsSnap] = await Promise.all([
    db.collection("security").doc("blocked_ips").get(),
    db.collection("security_logs").orderBy("createdAt", "desc").limit(20).get(),
  ]);
  res.json({
    blockedIPs: blockedSnap.exists ? (blockedSnap.data().ips || []) : [],
    recentLogs: logsSnap.docs.map(d => ({ id: d.id, ...d.data() })),
    rateLimitEntries: rateLimitStore.size,
  });
}

module.exports = {
  securityMiddleware,
  validateCORS,
  applySecurityHeaders,
  sanitizeString,
  sanitizeSearchQuery,
  containsInjection,
  handleSecurityStatus,
  blockIP,
  getClientIP,
};
