// ================================================================
// /functions/trending.js — YojanaHub Trending Engine
// Calculates trending content, breaking news ticker, CTR boost
// ================================================================

"use strict";

const admin = require("firebase-admin");
const db    = admin.firestore();

// ── Breaking News Items (rotated dynamically) ────────────────────
const BREAKING_NEWS = [
  "🔴 PM Kisan 20th Installment date announced – Check Status Now",
  "🔴 SSC GD Constable 2026 – 45,000 posts notification released",
  "🔴 Mudra Loan interest rate reduced – Apply Now for ₹10 Lakh",
  "🔴 Ayushman Bharat card – New 70+ age group added 2026",
  "🔴 RRB Group D 32,000 vacancies – Last date approaching",
  "🔴 PM Ujjwala Yojana 3.0 – New applications open",
  "🔴 Agniveer Navy 2026 – Online registration starts",
  "🔴 PMFBY – Crop insurance deadline for Rabi season 2026",
  "🔴 E-Shram card – ₹500 benefit transferred to accounts",
  "🔴 SSC CGL 2026 Notification – 17,727 posts released",
];

async function updateTrending() {
  const [schemeSnap, jobSnap, blogSnap] = await Promise.all([
    db.collection("schemes").orderBy("views", "desc").limit(20).get(),
    db.collection("jobs").orderBy("views", "desc").limit(10).get(),
    db.collection("blogs").where("status", "==", "published").orderBy("views", "desc").limit(10).get(),
  ]);

  const batch = db.batch();

  // Reset all trending flags for schemes and jobs
  const [allSchemes, allJobs] = await Promise.all([
    db.collection("schemes").get(),
    db.collection("jobs").get(),
  ]);

  // Process in smaller batches to avoid 500 limit
  const resetBatch1 = db.batch();
  allSchemes.docs.slice(0, 490).forEach(d => resetBatch1.update(d.ref, { isTrending: false }));
  await resetBatch1.commit();

  const resetBatch2 = db.batch();
  allJobs.docs.slice(0, 490).forEach(d => resetBatch2.update(d.ref, { isTrending: false }));
  await resetBatch2.commit();

  // Mark top as trending
  const trendBatch = db.batch();
  schemeSnap.forEach(d => trendBatch.update(d.ref, { isTrending: true }));
  jobSnap.forEach(d => trendBatch.update(d.ref, { isTrending: true }));
  await trendBatch.commit();

  // Build trending summary
  const trendingSchemes = schemeSnap.docs.map(d => ({
    id: d.id,
    title_hi: d.data().title_hi || d.data().title,
    title_en: d.data().title_en || d.data().title,
    views: d.data().views || 0,
    category: d.data().category || "",
    benefit: d.data().benefit || "",
  }));

  const trendingJobs = jobSnap.docs.map(d => ({
    id: d.id,
    title: d.data().title || "",
    organization: d.data().organization || "",
    views: d.data().views || 0,
    posts: d.data().posts || 0,
    lastDate: d.data().lastDate || "",
  }));

  const trendingBlogs = blogSnap.docs.map(d => ({
    id: d.id,
    title: d.data().title || "",
    slug: d.data().slug || d.id,
    views: d.data().views || 0,
    category: d.data().category || "",
  }));

  // Pick random breaking news
  const todayNews = BREAKING_NEWS.sort(() => Math.random() - 0.5).slice(0, 5);

  // Write cache doc
  await db.collection("cache").doc("trending").set({
    schemes: trendingSchemes,
    jobs: trendingJobs,
    blogs: trendingBlogs,
    breakingNews: todayNews,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  // Write analytics aggregate
  await db.collection("cache").doc("stats").set({
    totalSchemes: allSchemes.size,
    totalJobs: allJobs.size,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  }, { merge: true });

  console.log(`✅ Trending: ${trendingSchemes.length} schemes, ${trendingJobs.length} jobs, ${trendingBlogs.length} blogs`);
  return { schemes: trendingSchemes.length, jobs: trendingJobs.length, blogs: trendingBlogs.length };
}

// ── Track Click (for analytics) ─────────────────────────────────
async function trackClick(collectionName, docId, metadata = {}) {
  if (!["schemes", "jobs", "blogs"].includes(collectionName)) return;

  await db.collection("clicks").add({
    collection: collectionName,
    docId,
    ...metadata,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  await db.collection(collectionName).doc(docId).update({
    views: admin.firestore.FieldValue.increment(1),
  });
}

// ── Get Trending Cache ──────────────────────────────────────────
async function getTrending() {
  const cacheDoc = await db.collection("cache").doc("trending").get();
  if (!cacheDoc.exists) {
    await updateTrending();
    const fresh = await db.collection("cache").doc("trending").get();
    return fresh.data();
  }
  return cacheDoc.data();
}

module.exports = { updateTrending, trackClick, getTrending, BREAKING_NEWS };
