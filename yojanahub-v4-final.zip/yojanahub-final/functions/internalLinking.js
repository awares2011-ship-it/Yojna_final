// ================================================================
// /functions/internalLinking.js — YojanaHub Internal Linking Engine
// Auto-injects related blogs/schemes/jobs into every blog post
// Boosts SEO crawlability + user engagement + AdSense RPM
// ================================================================
"use strict";

const admin = require("firebase-admin");
const db = admin.firestore();

// ── Get related content for a blog ──────────────────────────────
async function getRelatedContent(blogDoc) {
  const { category, keywords = [], slug } = blogDoc;
  const kws = keywords.slice(0, 3);

  // Run queries in parallel
  const [relatedBlogsSnap, schemesSnap, jobsSnap] = await Promise.all([
    // Related blogs same category
    db.collection("blogs")
      .where("status", "==", "published")
      .where("category", "==", category)
      .orderBy("views", "desc")
      .limit(8)
      .get(),
    // Related schemes
    db.collection("schemes")
      .orderBy("views", "desc")
      .limit(6)
      .get(),
    // Related jobs
    db.collection("jobs")
      .where("expired", "!=", true)
      .orderBy("expired")
      .orderBy("views", "desc")
      .limit(4)
      .get(),
  ]);

  const relatedBlogs = relatedBlogsSnap.docs
    .filter(d => d.data().slug !== slug)
    .slice(0, 4)
    .map(d => ({
      title: d.data().title,
      slug: d.data().slug || d.id,
      category: d.data().category || "",
      views: d.data().views || 0,
    }));

  const relatedSchemes = schemesSnap.docs.slice(0, 4).map(d => ({
    id: d.id,
    title: d.data().title_hi || d.data().title_en || d.data().title || "Scheme",
    category: d.data().category || "",
    benefit: d.data().benefit || "",
  }));

  const relatedJobs = jobsSnap.docs.slice(0, 3).map(d => ({
    id: d.id,
    title: d.data().title || "Sarkari Naukri",
    organization: d.data().organization || "",
    lastDate: d.data().lastDate || "",
    posts: d.data().posts || 0,
  }));

  return { relatedBlogs, relatedSchemes, relatedJobs };
}

// ── Build Related Blogs HTML Section ─────────────────────────────
function buildRelatedBlogsSection(relatedBlogs) {
  if (!relatedBlogs.length) return "";
  const items = relatedBlogs.map(b =>
    `<a href="/blog/${b.slug}.html" style="display:block;padding:10px 14px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;text-decoration:none;color:#111827;font-weight:600;font-size:.9rem;line-height:1.4;transition:all .2s;" onmouseover="this.style.background='#f0fdf4';this.style.borderColor='#16a34a'" onmouseout="this.style.background='#fff';this.style.borderColor='#e5e7eb'">
  <span style="color:#16a34a;font-size:.75rem;font-weight:700;display:block;margin-bottom:3px;">${b.category || "Blog"}</span>
  ${b.title}
</a>`
  ).join("\n");

  return `
<!-- Related Blogs — Auto Injected by YojanaHub Linking Engine -->
<section style="background:#fafaf5;border:1px solid #e5e7eb;border-radius:14px;padding:24px;margin:36px 0;" aria-label="Related Articles">
  <h3 style="font-size:1.15rem;font-weight:800;color:#166534;margin:0 0 16px;display:flex;align-items:center;gap:8px;">
    📚 <span>Related Articles – Aur Padhein</span>
  </h3>
  <div style="display:grid;gap:10px;">
    ${items}
  </div>
  <a href="/blog/" style="display:inline-block;margin-top:16px;color:#16a34a;font-weight:700;font-size:.85rem;text-decoration:none;">→ Sabhi Blogs Dekhein</a>
</section>`;
}

// ── Build Related Schemes HTML Section ───────────────────────────
function buildRelatedSchemesSection(relatedSchemes) {
  if (!relatedSchemes.length) return "";
  const items = relatedSchemes.map(s =>
    `<a href="/scheme.html?id=${s.id}" style="display:flex;flex-direction:column;padding:12px 16px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;text-decoration:none;color:#111827;transition:all .2s;" onmouseover="this.style.borderColor='#16a34a'" onmouseout="this.style.borderColor='#e5e7eb'">
  <span style="font-weight:700;font-size:.9rem;color:#111827;line-height:1.35;">${s.title}</span>
  ${s.benefit ? `<span style="font-size:.78rem;color:#16a34a;font-weight:600;margin-top:4px;">${s.benefit}</span>` : ""}
</a>`
  ).join("\n");

  return `
<!-- Related Schemes — Auto Injected -->
<section style="background:#f0fdf4;border:2px solid #bbf7d0;border-radius:14px;padding:24px;margin:36px 0;" aria-label="Related Government Schemes">
  <h3 style="font-size:1.15rem;font-weight:800;color:#166534;margin:0 0 16px;display:flex;align-items:center;gap:8px;">
    🏛️ <span>Related Government Schemes</span>
  </h3>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px;">
    ${items}
  </div>
  <a href="/scheme.html" style="display:inline-block;margin-top:16px;background:#16a34a;color:#fff;padding:8px 20px;border-radius:8px;font-weight:700;font-size:.85rem;text-decoration:none;">📋 Sabhi Yojanayein Dekhein</a>
</section>`;
}

// ── Build Related Jobs HTML Section ──────────────────────────────
function buildRelatedJobsSection(relatedJobs) {
  if (!relatedJobs.length) return "";
  const items = relatedJobs.map(j =>
    `<a href="/job.html?id=${j.id}" style="display:flex;justify-content:space-between;align-items:center;padding:12px 16px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;text-decoration:none;gap:12px;transition:all .2s;" onmouseover="this.style.borderColor='#ea580c'" onmouseout="this.style.borderColor='#e5e7eb'">
  <div>
    <div style="font-weight:700;font-size:.88rem;color:#111827;line-height:1.3;">${j.title}</div>
    <div style="font-size:.76rem;color:#6b7280;margin-top:2px;">${j.organization}</div>
  </div>
  ${j.lastDate ? `<div style="font-size:.73rem;color:#ea580c;font-weight:700;white-space:nowrap;">Last: ${j.lastDate}</div>` : ""}
</a>`
  ).join("\n");

  return `
<!-- Related Jobs — Auto Injected -->
<section style="background:#fff7ed;border:2px solid #fed7aa;border-radius:14px;padding:24px;margin:36px 0;" aria-label="Government Jobs">
  <h3 style="font-size:1.15rem;font-weight:800;color:#9a3412;margin:0 0 16px;display:flex;align-items:center;gap:8px;">
    💼 <span>Latest Sarkari Naukri 2026</span>
  </h3>
  <div style="display:grid;gap:10px;">
    ${items}
  </div>
  <a href="/job.html" style="display:inline-block;margin-top:16px;background:#ea580c;color:#fff;padding:8px 20px;border-radius:8px;font-weight:700;font-size:.85rem;text-decoration:none;">💼 Sabhi Jobs Dekhein</a>
</section>`;
}

// ── Build Full Read-More Section ──────────────────────────────────
function buildReadMoreSection(relatedBlogs, relatedSchemes, relatedJobs) {
  return buildRelatedBlogsSection(relatedBlogs)
    + buildRelatedSchemesSection(relatedSchemes)
    + buildRelatedJobsSection(relatedJobs);
}

// ── HTTP Function Handler ─────────────────────────────────────────
async function handleInternalLinksAPI(req, res) {
  res.set("Access-Control-Allow-Origin", "*");
  if (req.method === "OPTIONS") return res.sendStatus(204);

  const { slug } = req.query;
  if (!slug) return res.status(400).json({ error: "slug required" });

  try {
    const snap = await db.collection("blogs")
      .where("slug", "==", slug)
      .where("status", "==", "published")
      .limit(1)
      .get();

    if (snap.empty) return res.status(404).json({ error: "Blog not found" });

    const blogData = snap.docs[0].data();
    const { relatedBlogs, relatedSchemes, relatedJobs } = await getRelatedContent(blogData);

    const readMoreHTML = buildReadMoreSection(relatedBlogs, relatedSchemes, relatedJobs);

    res.set("Cache-Control", "public, max-age=1800");
    res.json({ relatedBlogs, relatedSchemes, relatedJobs, readMoreHTML });
  } catch (err) {
    console.error("Internal linking error:", err.message);
    res.status(500).json({ error: err.message });
  }
}

// ── Backfill internal links for existing blogs ────────────────────
async function backfillInternalLinks(limit = 50) {
  const snap = await db.collection("blogs")
    .where("status", "==", "published")
    .orderBy("createdAt", "desc")
    .limit(limit)
    .get();

  let updated = 0;
  const batch = db.batch();

  for (const doc of snap.docs) {
    const data = doc.data();
    if (data.internalLinks && data.internalLinks.length > 0) continue;

    const related = await db.collection("blogs")
      .where("status", "==", "published")
      .where("category", "==", data.category || "Government Scheme")
      .limit(5)
      .get();

    const internalLinks = related.docs
      .filter(d => d.id !== doc.id)
      .slice(0, 3)
      .map(d => ({ title: d.data().title, slug: d.data().slug || d.id }));

    batch.update(doc.ref, { internalLinks });
    updated++;
  }

  if (updated > 0) await batch.commit();
  console.log(`Backfilled internal links for ${updated} blogs`);
  return updated;
}

module.exports = {
  handleInternalLinksAPI,
  getRelatedContent,
  buildReadMoreSection,
  buildRelatedBlogsSection,
  buildRelatedSchemesSection,
  buildRelatedJobsSection,
  backfillInternalLinks,
};
