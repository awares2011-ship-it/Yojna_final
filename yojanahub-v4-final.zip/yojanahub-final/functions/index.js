// ================================================================
// /functions/index.js — YojanaHub Automation Engine v4.0
// Systems: Blog Scaling | Internal Linking | Security | Analytics | Trending
// ================================================================
"use strict";

const functions = require("firebase-functions");
const admin     = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();

const { scrapeSchemes, scrapeJobs }           = require("./scraper");
const { generateBlogs }                        = require("./blogGenerator");
const { updateTrending, getTrending }          = require("./trending");
const { handleInternalLinksAPI, backfillInternalLinks } = require("./internalLinking");
const { handleSeedBlogs }                      = require("./seedBlogs");
const {
  securityMiddleware, validateCORS, sanitizeSearchQuery,
  sanitizeString, handleSecurityStatus, applySecurityHeaders,
} = require("./security");

function slugify(t){return t.toLowerCase().replace(/[^\w\s-]/g,"").replace(/[\s_-]+/g,"-").replace(/^-+|-+$/g,"").substring(0,80);}

// ══════════════════════════════════════════════════════════════════
// CRON JOBS — Automation Engine
// ══════════════════════════════════════════════════════════════════

// 1. Scrape Schemes every 6h
exports.scrapeSchemes = functions.pubsub.schedule("0 */6 * * *").timeZone("Asia/Kolkata")
  .onRun(async()=>{ await scrapeSchemes(); return null; });

// 2. Scrape Jobs every 6h (offset 30m)
exports.scrapeJobs = functions.pubsub.schedule("30 */6 * * *").timeZone("Asia/Kolkata")
  .onRun(async()=>{ await scrapeJobs(); return null; });

// 3. Generate 3 AI blogs daily at 5AM IST
exports.generateBlogs = functions.pubsub.schedule("0 5 * * *").timeZone("Asia/Kolkata")
  .onRun(async()=>{
    const apiKey = functions.config().anthropic?.key;
    const count  = await generateBlogs(apiKey, 3);
    if(count > 0) await _buildAndStoreSitemap();
    return null;
  });

// 4. Generate 2 more blogs at 2PM IST (total ~5/day)
exports.generateBlogsPM = functions.pubsub.schedule("0 14 * * *").timeZone("Asia/Kolkata")
  .onRun(async()=>{
    const apiKey = functions.config().anthropic?.key;
    const count  = await generateBlogs(apiKey, 2);
    if(count > 0) await _buildAndStoreSitemap();
    return null;
  });

// 5. Update trending every 12h
exports.updateTrending = functions.pubsub.schedule("0 */12 * * *").timeZone("Asia/Kolkata")
  .onRun(async()=>{ await updateTrending(); return null; });

// 6. Rebuild sitemap daily 3AM
exports.scheduledSitemap = functions.pubsub.schedule("0 3 * * *").timeZone("Asia/Kolkata")
  .onRun(async()=>{ await _buildAndStoreSitemap(); return null; });

// 7. Weekly cleanup (analytics 90d+ + expired jobs)
exports.weeklyCleanup = functions.pubsub.schedule("0 2 * * 0").timeZone("Asia/Kolkata")
  .onRun(async()=>{
    const cutoff=new Date(); cutoff.setDate(cutoff.getDate()-90);
    const old=await db.collection("analytics").where("createdAt","<",cutoff).limit(500).get();
    if(!old.empty){const b=db.batch();old.forEach(d=>b.delete(d.ref));await b.commit();}
    const today=new Date().toISOString().split("T")[0];
    const expired=await db.collection("jobs").where("lastDate","<",today).limit(100).get();
    if(!expired.empty){const b2=db.batch();expired.forEach(d=>b2.update(d.ref,{expired:true}));await b2.commit();}
    // Clean old security logs (30d+)
    const secCutoff=new Date(); secCutoff.setDate(secCutoff.getDate()-30);
    const secOld=await db.collection("security_logs").where("createdAt","<",secCutoff).limit(200).get();
    if(!secOld.empty){const b3=db.batch();secOld.forEach(d=>b3.delete(d.ref));await b3.commit();}
    return null;
  });

// 8. Weekly: Backfill internal links for blogs
exports.backfillLinks = functions.pubsub.schedule("0 4 * * 1").timeZone("Asia/Kolkata")
  .onRun(async()=>{ await backfillInternalLinks(100); return null; });

// ══════════════════════════════════════════════════════════════════
// HTTP ENDPOINTS
// ══════════════════════════════════════════════════════════════════

// 9. Serve sitemap.xml
exports.sitemap = functions.https.onRequest(async(req,res)=>{
  applySecurityHeaders(res);
  try {
    const doc=await db.collection("cache").doc("sitemap").get();
    if(doc.exists){
      const age=Date.now()-(doc.data().updatedAt?.toMillis()||0);
      if(age<3600000){res.set("Content-Type","application/xml");res.set("Cache-Control","public,max-age=3600");return res.send(doc.data().xml);}
    }
    await _buildAndStoreSitemap();
    const fresh=await db.collection("cache").doc("sitemap").get();
    res.set("Content-Type","application/xml");res.send(fresh.data().xml);
  }catch(err){res.status(500).send("Sitemap error: "+err.message);}
});

// 10. Trigger sitemap rebuild
exports.generateSitemap = functions.https.onRequest(async(req,res)=>{
  const ok=await securityMiddleware(req,res,"api");
  if(!ok) return;
  await _buildAndStoreSitemap();
  res.json({success:true,message:"Sitemap regenerated"});
});

// 11. Search API (with security)
exports.search = functions.https.onRequest(async(req,res)=>{
  validateCORS(req,res);
  if(req.method==="OPTIONS") return res.sendStatus(204);
  const ok=await securityMiddleware(req,res,"search");
  if(!ok) return;
  const q=sanitizeSearchQuery(req.query.q||"").toLowerCase().trim();
  if(!q||q.length<2) return res.json({schemes:[],jobs:[],blogs:[]});
  const [ss,js,bs]=await Promise.all([
    db.collection("schemes").limit(80).get(),
    db.collection("jobs").limit(80).get(),
    db.collection("blogs").where("status","==","published").limit(80).get(),
  ]);
  const match=t=>t&&t.toLowerCase().includes(q);
  const schemes=ss.docs.filter(d=>{const v=d.data();return match(v.title_hi)||match(v.title_en)||match(v.category)||match(v.state)||(v.keywords||[]).some(k=>k.includes(q));}).slice(0,8).map(d=>({id:d.id,...d.data()}));
  const jobs=js.docs.filter(d=>{const v=d.data();return match(v.title)||match(v.organization)||match(v.category);}).slice(0,8).map(d=>({id:d.id,...d.data()}));
  const blogs=bs.docs.filter(d=>{const v=d.data();return match(v.title)||(v.keywords||[]).some(k=>k.includes(q));}).slice(0,5).map(d=>({id:d.id,title:d.data().title,slug:d.data().slug}));
  res.set("Cache-Control","public,max-age=300");
  res.json({schemes,jobs,blogs,query:q});
});

// 12. Trending API (with security)
exports.trending = functions.https.onRequest(async(req,res)=>{
  validateCORS(req,res);
  if(req.method==="OPTIONS") return res.sendStatus(204);
  const ok=await securityMiddleware(req,res,"trending");
  if(!ok) return;
  try {
    const data=await getTrending();
    res.set("Cache-Control","public,max-age=1800");
    res.json(data);
  }catch(err){res.status(500).json({error:err.message});}
});

// 13. Internal Links API — new
exports.internalLinks = functions.https.onRequest(async(req,res)=>{
  validateCORS(req,res);
  if(req.method==="OPTIONS") return res.sendStatus(204);
  const ok=await securityMiddleware(req,res,"api");
  if(!ok) return;
  await handleInternalLinksAPI(req,res);
});

// 14. Seed Blogs — one-time (protected)
exports.seedBlogs = functions.https.onRequest(async(req,res)=>{
  applySecurityHeaders(res);
  const SECRET=functions.config().seed?.key||"seed2026secure";
  await handleSeedBlogs(req,res,SECRET);
});

// 15. Seed Data (schemes + jobs + trending + sitemap)
exports.seedData = functions.https.onRequest(async(req,res)=>{
  applySecurityHeaders(res);
  const SECRET=functions.config().seed?.key||"seed2026";
  if(req.query.key!==SECRET) return res.status(403).send("Forbidden");
  const[s,j]=await Promise.all([scrapeSchemes(),scrapeJobs()]);
  await updateTrending();
  await _buildAndStoreSitemap();
  res.json({message:"Seed complete",schemes:s,jobs:j});
});

// 16. Security Status (admin only)
exports.securityStatus = functions.https.onRequest(async(req,res)=>{
  applySecurityHeaders(res);
  const SECRET=functions.config().security?.admin_key||"";
  await handleSecurityStatus({...req,query:{...req.query,key:req.query.key||""}},res);
});

// ══════════════════════════════════════════════════════════════════
// CALLABLE FUNCTIONS
// ══════════════════════════════════════════════════════════════════

// 17. Increment view count
exports.incrementView = functions.https.onCall(async(data)=>{
  const{collectionName,docId}=data;
  if(!["schemes","jobs","blogs"].includes(collectionName))
    throw new functions.https.HttpsError("permission-denied","Invalid collection");
  await db.collection(collectionName).doc(docId).update({views:admin.firestore.FieldValue.increment(1)});
  return{success:true};
});

// 18. Track analytics event
exports.trackUserActivity = functions.https.onCall(async(data)=>{
  const event=sanitizeString(data.event||"pageview",50);
  const page=sanitizeString(data.page||"/",200);
  await db.collection("analytics").add({
    event, page,
    duration:Number(data.duration)||0,
    referrer:sanitizeString(data.referrer||"",200),
    ua:sanitizeString(data.ua||"",200),
    category:sanitizeString(data.category||"",50),
    createdAt:admin.firestore.FieldValue.serverTimestamp(),
  });
  return{success:true};
});

// 19. Track click (for CTR analytics)
exports.trackClick = functions.https.onCall(async(data)=>{
  const{collectionName,docId,source}=data;
  if(!["schemes","jobs","blogs"].includes(collectionName||"")) return{success:false};
  await Promise.all([
    db.collection(collectionName).doc(docId).update({
      clicks:admin.firestore.FieldValue.increment(1),
      views:admin.firestore.FieldValue.increment(1),
    }),
    db.collection("clicks").add({
      collection:collectionName, docId,
      source:sanitizeString(source||"direct",50),
      createdAt:admin.firestore.FieldValue.serverTimestamp(),
    }),
  ]);
  return{success:true};
});

// 20. Save lead
exports.saveLead = functions.https.onCall(async(data)=>{
  const{name,mobile,interest}=data;
  const cleanName=sanitizeString(name||"",100);
  const cleanMobile=sanitizeString(mobile||"",15);
  if(!cleanName||cleanName.trim().length<2)
    throw new functions.https.HttpsError("invalid-argument","Valid name required");
  if(!cleanMobile||!/^\d{10}$/.test(cleanMobile))
    throw new functions.https.HttpsError("invalid-argument","Valid 10-digit mobile required");
  await db.collection("leads").add({
    name:cleanName.trim(), mobile:cleanMobile,
    interest:sanitizeString(interest||"general",100),
    createdAt:admin.firestore.FieldValue.serverTimestamp(),
    status:"new",
  });
  return{success:true,message:"Thank you! We will contact you shortly."};
});

// ══════════════════════════════════════════════════════════════════
// FIRESTORE TRIGGERS
// ══════════════════════════════════════════════════════════════════

// 21. Push notification on new scheme
exports.sendPushNotification = functions.firestore.document("schemes/{schemeId}")
  .onCreate(async(snap,context)=>{
    const s=snap.data();
    try {
      await admin.messaging().send({
        notification:{title:`New Scheme: ${s.title_hi||s.title_en}`,body:`${s.title_en||s.title_hi} – Abhi jankari payen!`},
        data:{url:`https://yojanahub.in/scheme.html?id=${context.params.schemeId}`,type:"new_scheme"},
        topic:"all_users",
      });
    }catch(err){console.error("Push error:",err.message);}
    return null;
  });

// 22. Auto-update sitemap when new blog published
exports.onBlogPublished = functions.firestore.document("blogs/{blogId}")
  .onCreate(async(snap)=>{
    const data=snap.data();
    if(data.status==="published"){
      await _buildAndStoreSitemap().catch(e=>console.error("Sitemap update failed:",e.message));
    }
    return null;
  });

// ══════════════════════════════════════════════════════════════════
// INTERNAL: Build & Store Sitemap
// ══════════════════════════════════════════════════════════════════
async function _buildAndStoreSitemap() {
  const BASE="https://yojanahub.in";
  const[schemes,jobs,blogs]=await Promise.all([
    db.collection("schemes").orderBy("createdAt","desc").limit(300).get(),
    db.collection("jobs").orderBy("createdAt","desc").limit(300).get(),
    db.collection("blogs").where("status","==","published").orderBy("createdAt","desc").limit(500).get(),
  ]);
  const today=new Date().toISOString().split("T")[0];
  let urls=[
    `<url><loc>${BASE}/</loc><changefreq>daily</changefreq><priority>1.0</priority><lastmod>${today}</lastmod></url>`,
    `<url><loc>${BASE}/scheme.html</loc><changefreq>daily</changefreq><priority>0.9</priority><lastmod>${today}</lastmod></url>`,
    `<url><loc>${BASE}/job.html</loc><changefreq>daily</changefreq><priority>0.9</priority><lastmod>${today}</lastmod></url>`,
    `<url><loc>${BASE}/blog/</loc><changefreq>daily</changefreq><priority>0.8</priority><lastmod>${today}</lastmod></url>`,
    `<url><loc>${BASE}/about.html</loc><changefreq>monthly</changefreq><priority>0.5</priority></url>`,
    `<url><loc>${BASE}/contact.html</loc><changefreq>monthly</changefreq><priority>0.5</priority></url>`,
    `<url><loc>${BASE}/privacy.html</loc><changefreq>monthly</changefreq><priority>0.4</priority></url>`,
    `<url><loc>${BASE}/disclaimer.html</loc><changefreq>monthly</changefreq><priority>0.4</priority></url>`,
  ];
  ["maharashtra","uttar-pradesh","delhi","rajasthan","bihar","gujarat","madhya-pradesh","karnataka","tamil-nadu","west-bengal","andhra-pradesh","telangana","punjab","haryana","jharkhand","odisha","chhattisgarh","uttarakhand","himachal-pradesh","assam"].forEach(s=>urls.push(`<url><loc>${BASE}/state/${s}</loc><changefreq>weekly</changefreq><priority>0.7</priority></url>`));
  ["farmer","women","student","business","health","housing","education","loan","insurance","energy","senior-citizen","skill-development","defence","banking","subsidy","finance"].forEach(c=>urls.push(`<url><loc>${BASE}/category/${c}</loc><changefreq>weekly</changefreq><priority>0.7</priority></url>`));
  schemes.forEach(d=>{const upd=d.data().updatedAt?.toDate().toISOString().split("T")[0]||today;urls.push(`<url><loc>${BASE}/scheme.html?id=${d.id}</loc><changefreq>weekly</changefreq><priority>0.8</priority><lastmod>${upd}</lastmod></url>`);});
  jobs.forEach(d=>{const upd=d.data().updatedAt?.toDate().toISOString().split("T")[0]||today;urls.push(`<url><loc>${BASE}/job.html?id=${d.id}</loc><changefreq>weekly</changefreq><priority>0.8</priority><lastmod>${upd}</lastmod></url>`);});
  blogs.forEach(d=>{const slug=d.data().slug||d.id;const pub=d.data().publishDate||today;urls.push(`<url><loc>${BASE}/blog/${slug}.html</loc><changefreq>monthly</changefreq><priority>0.7</priority><lastmod>${pub}</lastmod></url>`);});
  const xml=`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join("\n")}\n</urlset>`;
  await db.collection("cache").doc("sitemap").set({xml,count:urls.length,updatedAt:admin.firestore.FieldValue.serverTimestamp()});
  console.log(`Sitemap: ${urls.length} URLs`);
}
