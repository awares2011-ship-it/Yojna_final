// YojanaHub Enhanced – Shared JS v5.0
// ============================================================

(function () {
  'use strict';

  /* ── INTERSECTION OBSERVER for .reveal ── */
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.reveal').forEach(el => io.observe(el));
  } else {
    document.querySelectorAll('.reveal').forEach(el => el.classList.add('visible'));
  }

  /* ── STICKY AD SHOW ── */
  const stickyAd = document.getElementById('footer-sticky-ad');
  if (stickyAd) {
    setTimeout(() => stickyAd.classList.add('show'), 4000);
  }

  /* ── CLOSE STICKY AD ── */
  window.closeStickyAd = function () {
    const el = document.getElementById('footer-sticky-ad');
    if (el) el.classList.remove('show');
  };

  /* ── DATE IN TOPBAR ── */
  const dateEl = document.getElementById('topbar-date');
  if (dateEl) {
    const d = new Date();
    dateEl.textContent = d.toLocaleDateString('hi-IN', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });
  }

  /* ── LANG TOGGLE ── */
  let isHindi = true;
  window.toggleLang = function () {
    isHindi = !isHindi;
    const btn = document.getElementById('lang-btn');
    if (btn) btn.textContent = isHindi ? '🔤 English' : '🔤 हिंदी';
    document.documentElement.lang = isHindi ? 'hi' : 'en';
  };

  /* ── SEARCH ── */
  window.initSearch = function (allData) {
    const input = document.getElementById('search-input');
    const box = document.getElementById('search-results');
    if (!input || !box) return;

    input.addEventListener('input', function () {
      const q = this.value.trim().toLowerCase();
      if (!q) { box.classList.remove('show'); return; }
      const results = allData.filter(d =>
        (d.label || '').toLowerCase().includes(q) || (d.sub || '').toLowerCase().includes(q)
      ).slice(0, 6);
      if (!results.length) { box.classList.remove('show'); return; }
      box.innerHTML = results.map(r => `
        <a class="search-result-item" href="${r.href}">
          <span style="font-size:1.1rem;flex-shrink:0">${r.icon}</span>
          <div>
            <div style="font-size:0.85rem;color:#1f2937">${r.label}</div>
            <div style="font-size:0.7rem;color:#6b7280">${r.sub}</div>
          </div>
        </a>`).join('');
      box.classList.add('show');
    });

    document.addEventListener('click', function (e) {
      if (!e.target.closest('.search-wrap')) box.classList.remove('show');
    });

    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') window.doSearch();
    });
  };

  window.doSearch = function () {
    const q = document.getElementById('search-input');
    if (q && q.value.trim()) window.location.href = 'search.html?q=' + encodeURIComponent(q.value.trim());
  };

  /* ── ELIGIBILITY CHECKER ── */
  window.checkEligibility = function () {
    const age = parseInt(document.getElementById('ck-age')?.value);
    const income = document.getElementById('ck-income')?.value;
    const cat = document.getElementById('ck-cat')?.value;
    const result = document.getElementById('checker-result');
    if (!result) return;

    if (!age || !income) {
      result.innerHTML = '⚠️ कृपया उम्र और आय भरें।';
      result.classList.add('show'); return;
    }

    const map = {
      'किसान':         ['PM Kisan Samman Nidhi', 'Kisan Credit Card', 'Fasal Bima Yojana', 'PM Krishi Sinchai'],
      'छात्र':          ['NSP Scholarship', 'PM Scholarship Scheme', 'Education Loan Subsidy', 'Free Coaching Scheme'],
      'महिला':          ['Sukanya Samriddhi Yojana', 'PM Ujjwala Yojana', 'Mahila Samman Bachat Patra', 'SHG Loan'],
      'वरिष्ठ नागरिक':  ['Atal Pension Yojana', 'PM Vaya Vandana', 'Senior Citizen Savings Scheme'],
      'व्यापारी':        ['PM Mudra Loan', 'Startup India', 'Stand Up India', 'PM SVANidhi'],
    };

    let schemes = map[cat] || (income === '0' || income === '1'
      ? ['Ayushman Bharat', 'PM Awas Yojana', 'Ration Card', 'PM Ujjwala']
      : ['PM Mudra Loan', 'Startup India', 'Education Loan Subsidy']);

    result.innerHTML = `✅ <b>आप ${schemes.length} योजनाओं के लिए पात्र हो सकते हैं:</b><br>` + schemes.map(s => `• ${s}`).join('<br>') + `<br><a href="scheme.html" style="color:#2e7d32;font-weight:700;text-decoration:underline">सभी देखें →</a>`;
    result.classList.add('show');
  };

  /* ── LEAD FORM ── */
  window.submitLead = function () {
    const name = document.getElementById('lead-name')?.value.trim();
    const mobile = document.getElementById('lead-mobile')?.value.trim();
    if (!name || !mobile || mobile.length !== 10) {
      alert('कृपया सही नाम और 10 अंकों का मोबाइल नंबर दर्ज करें।'); return;
    }
    alert('✅ धन्यवाद ' + name + '! हमारे विशेषज्ञ जल्द ही आपसे संपर्क करेंगे।');
    if (document.getElementById('lead-name')) document.getElementById('lead-name').value = '';
    if (document.getElementById('lead-mobile')) document.getElementById('lead-mobile').value = '';
  };

  /* ── PUSH NOTIF ── */
  window.enablePush = function () {
    const banner = document.getElementById('push-banner');
    if ('Notification' in window) {
      Notification.requestPermission().then(() => { if (banner) banner.style.display = 'none'; });
    } else {
      if (banner) banner.style.display = 'none';
    }
  };

  /* ── ANIMATE NUMBERS ── */
  window.animateStats = function () {
    const targets = { 'stat-schemes': 500, 'stat-jobs': 1200, 'stat-states': 28 };
    Object.entries(targets).forEach(([id, target]) => {
      const el = document.getElementById(id);
      if (!el) return;
      let current = 0;
      const step = Math.ceil(target / 50);
      const timer = setInterval(() => {
        current = Math.min(current + step, target);
        el.textContent = current >= 1000 ? (current / 1000).toFixed(1) + 'K+' : current + '+';
        if (current >= target) clearInterval(timer);
      }, 22);
    });
  };

  /* ── MOBILE MENU (stub) ── */
  window.toggleMobileMenu = function () {};

  /* ── MOBILE AD ── */
  window.closeMobileAd = function () {
    const el = document.querySelector('.footer-sticky-ad');
    if (el) el.classList.remove('show');
  };

})();
