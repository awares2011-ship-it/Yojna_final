// Inject shared NOT-GOVT bar, ticker, topbar, and footer enhancements
(function() {
  // Inject not-govt bar before topbar if not already present
  if (!document.querySelector('.not-govt-bar')) {
    const bar = document.createElement('div');
    bar.className = 'not-govt-bar';
    bar.innerHTML = '⚠️ <span>यह एक निजी सूचना पोर्टल है — यह कोई सरकारी वेबसाइट नहीं है।</span> &nbsp;|&nbsp; This is NOT an official Government website.';
    document.body.insertBefore(bar, document.body.firstChild);
  }

  // Inject floating CTA
  if (!document.querySelector('.floating-cta')) {
    const cta = document.createElement('a');
    cta.className = 'floating-cta';
    cta.href = 'scheme.html';
    cta.textContent = 'Apply Now 🚀';
    document.body.appendChild(cta);
  }

  // Inject footer sticky ad
  if (!document.querySelector('.footer-sticky-ad')) {
    const ad = document.createElement('div');
    ad.className = 'footer-sticky-ad';
    ad.id = 'footer-sticky-ad';
    ad.innerHTML = '<div class="sticky-ad-content">📢 AdSense Anchor — सरकारी योजनाएं Apply करें 🚀</div><button class="sticky-ad-close" onclick="closeStickyAd()">✕</button>';
    document.body.appendChild(ad);
    setTimeout(() => ad.classList.add('show'), 4000);
  }
})();
